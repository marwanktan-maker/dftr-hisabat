const crypto = require("node:crypto");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");
const { defineSecret } = require("firebase-functions/params");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");

initializeApp();

const REGION = "asia-south1";
const TOPIC = "hasabi_ledger_events";
const PASSWORD_MARWAN = defineSecret("HASABI_PASSWORD_MARWAN");
const PASSWORD_MOHAMMED = defineSecret("HASABI_PASSWORD_MOHAMMED");
const PASSWORD_MAZEN = defineSecret("HASABI_PASSWORD_MAZEN");

function passwordMatches(candidate, secretValue) {
  const expected = String(secretValue || "");
  if (!/^[A-Za-z0-9]{5,64}$/.test(expected) || candidate.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(candidate), Buffer.from(expected));
}

exports.exchangePasswordForCustomToken = onCall(
  {
    region: REGION,
    enforceAppCheck: true,
    secrets: [PASSWORD_MARWAN, PASSWORD_MOHAMMED, PASSWORD_MAZEN],
  },
  async (request) => {
    const candidate = String(request.data?.password || "");
    const requestedName = String(request.data?.userName || "");
    const deviceId = String(request.data?.deviceId || "");
    if (!/^[A-Za-z0-9]{5,64}$/.test(candidate) || !["مروان", "محمد", "مازن"].includes(requestedName) || deviceId.length < 12 || deviceId.length > 100) {
      throw new HttpsError("unauthenticated", "بيانات الدخول أو الجهاز غير معتمد.");
    }

    const ip = String(request.rawRequest.ip || "unknown");
    const rateKey = crypto.createHash("sha256").update(`${ip}:${deviceId}`).digest("hex");
    const attemptRef = getFirestore().collection("_private_password_attempts").doc(rateKey);
    const now = Date.now();
    const match = await getFirestore().runTransaction(async (tx) => {
      const attempt = await tx.get(attemptRef);
      const blockedUntil = Number(attempt.get("blockedUntil") || 0);
      if (blockedUntil > now) {
        throw new HttpsError("resource-exhausted", "محاولات كثيرة؛ انتظر 15 دقيقة ثم حاول مجدداً.");
      }
      const windowStart = Number(attempt.get("windowStart") || 0);
      const previousCount = windowStart > now - 15 * 60 * 1000 ? Number(attempt.get("count") || 0) : 0;
      const users = [
        { password: PASSWORD_MARWAN.value(), uid: "hasabi-marwan", userName: "مروان", role: "ADMIN" },
        { password: PASSWORD_MOHAMMED.value(), uid: "hasabi-mohammed", userName: "محمد", role: "USER" },
        { password: PASSWORD_MAZEN.value(), uid: "hasabi-mazen", userName: "مازن", role: "USER" },
      ];
      const user = users.find((item) => passwordMatches(candidate, item.password));
      if (user && user.userName === requestedName) {
        tx.delete(attemptRef);
        return user;
      }
      const nextCount = previousCount + 1;
      tx.set(attemptRef, {
        windowStart: previousCount === 0 ? now : windowStart,
        count: nextCount,
        blockedUntil: nextCount >= 5 ? now + 15 * 60 * 1000 : 0,
      });
      return null;
    });

    if (!match) throw new HttpsError("unauthenticated", "الاسم أو كلمة السر غير صحيحة.");
    const token = await getAuth().createCustomToken(match.uid, {
      teamId: "hasabi",
      role: match.role,
      userName: match.userName,
    });
    return { token };
  }
);

async function sendLedgerNotice(type, title, body) {
  return getMessaging().send({
    topic: TOPIC,
    notification: { title, body },
    data: { type },
    android: {
      priority: "high",
      notification: { channelId: "ledger_events", sound: "default" },
    },
  });
}

exports.transferCreated = onDocumentCreated(
  { document: "transfers/{transferId}", region: REGION },
  async (event) => {
    const transfer = event.data?.data();
    if (!transfer) return;
    const received = transfer.received === true;
    return sendLedgerNotice(
      received ? "transfer_received" : "transfer_created",
      received ? "تم تأكيد استلام الحوالة" : "تم تسجيل حوالة جديدة",
      received
        ? "تم تسجيل استلام حوالة. افتح دفتر حسابات لمراجعة التفاصيل."
        : "تم تسجيل حوالة جديدة. افتح دفتر حسابات لمراجعة التفاصيل."
    );
  }
);


exports.expenseCreated = onDocumentCreated(
  { document: "expenses/{expenseId}", region: REGION },
  async (event) => {
    if (!event.data) return;
    return sendLedgerNotice(
      "expense_created",
      "تم تسجيل مصروف جديد",
      "تمت إضافة مصروف جديد إلى دفتر الحسابات. افتح التطبيق لمراجعة التفاصيل."
    );
  }
);

exports.expenseUpdated = onDocumentUpdated(
  { document: "expenses/{expenseId}", region: REGION },
  async (event) => {
    const before = event.data?.before.data();
    const after = event.data?.after.data();
    if (!before || !after) return;
    const changed = ["name", "amount", "paidAmount", "currency", "category", "trader", "date"]
      .some((key) => before[key] !== after[key]);
    if (!changed) return;
    return sendLedgerNotice(
      "expense_updated",
      "تم تحديث سجل حسابي",
      "تم تحديث سجل في دفتر الحسابات. افتح التطبيق لمراجعة التفاصيل."
    );
  }
);

exports.workerCreated = onDocumentCreated(
  { document: "worker_daily/{workerId}", region: REGION },
  async (event) => {
    if (!event.data) return;
    return sendLedgerNotice(
      "worker_created",
      "تم تسجيل أجر جديد",
      "تم تسجيل أجر جديد في دفتر الحسابات. افتح التطبيق لمراجعة التفاصيل."
    );
  }
);

exports.workerUpdated = onDocumentUpdated(
  { document: "worker_daily/{workerId}", region: REGION },
  async (event) => {
    const before = event.data?.before.data();
    const after = event.data?.after.data();
    if (!before || !after) return;
    const changed = ["paid", "paidAmountSAR", "paidAmountYER", "days", "dailyWageSAR", "dailyWageYER"]
      .some((key) => before[key] !== after[key]);
    if (!changed) return;
    return sendLedgerNotice(
      "worker_updated",
      "تم تحديث حالة أجر",
      "تم تحديث سجل أجور في دفتر الحسابات. افتح التطبيق لمراجعة التفاصيل."
    );
  }
);

exports.transferReceived = onDocumentUpdated(
  { document: "transfers/{transferId}", region: REGION },
  async (event) => {
    const before = event.data?.before.data();
    const after = event.data?.after.data();
    if (!before || !after || before.received === true || after.received !== true) return;
    return sendLedgerNotice(
      "transfer_received",
      "تم تأكيد استلام الحوالة",
      "أكد مازن استلام حوالة. افتح دفتر حسابات لمراجعة التفاصيل."
    );
  }
);

exports.settingsCreated = onDocumentCreated(
  { document: "app_settings/config", region: REGION },
  async (event) => {
    if (!event.data) return;
    return sendLedgerNotice(
      "settings_updated",
      "تم تعميم إعدادات جديدة",
      "تم تحديث إعدادات دفتر الحسابات. افتح التطبيق لمزامنتها."
    );
  }
);

exports.settingsUpdated = onDocumentUpdated(
  { document: "app_settings/config", region: REGION },
  async (event) => {
    if (!event.data) return;
    return sendLedgerNotice(
      "settings_updated",
      "تم تعميم إعدادات جديدة",
      "تم تحديث إعدادات دفتر الحسابات. افتح التطبيق لمزامنتها."
    );
  }
);
