package com.hasabi.app2024

object Constants {
    const val EXCHANGE_RATE = 140.0
    const val APP_NAME = "دفتر حسابات"
    const val PACKAGE = "com.hasabi.app2024"
    const val FAMILY_MONTHLY_LIMIT_SAR = 600.0
    const val DEFAULT_BUDGET_ALERT_SAR = 1000.0
    const val LEDGER_NOTIFICATIONS_TOPIC = "hasabi_ledger_events"
    val DEFAULT_EXPENSE_TYPES = listOf("مواد بناء", "بلوك", "اسمنت", "مواصير صرف صحي", "مواصير ماء", "مصاريف أهل", "أجور")
    fun yerToSar(yer: Double, exchangeRate: Double = EXCHANGE_RATE): Double = yer / exchangeRate
    fun sarToYer(sar: Double, exchangeRate: Double = EXCHANGE_RATE): Double = sar * exchangeRate
    val TEAM_MEMBERS = listOf("مروان", "محمد", "مازن")
    val BUILD_ROLES = listOf("مواد بناء", "مقاول", "سباك", "مهندس", "كهربائي", "نجار", "حداد", "عمال", "أخرى")
}

data class Hawala(
    val id: String = "",
    val number: String = "",
    val amountSAR: Double = 0.0,
    val amountYER: Double = amountSAR * Constants.EXCHANGE_RATE,
    val from: String = "",
    val recipient: String = "مازن",
    val date: Long = System.currentTimeMillis(),
    val createdBy: String = "",
    val received: Boolean = false,
    val receivedCurrency: String = "YER",
    val receivedAmount: Double = amountYER,
    val receivedAt: Long = 0L,
    val receiptImage: String = "",
    val exchangeRateAtEntry: Double = Constants.EXCHANGE_RATE,
    val receivedExchangeRate: Double = Constants.EXCHANGE_RATE
)

data class Expense(
    val id: String = "",
    val type: String = "",
    val trader: String = "",
    val amountYER: Double = 0.0,
    val amountSAR: Double = amountYER / Constants.EXCHANGE_RATE,
    val invoiceImage: String = "",
    val signature: String = "",
    val location: String = "",
    val date: Long = System.currentTimeMillis(),
    val createdBy: String = "مازن",
    val relatedTransferId: String = "",
    val exchangeRateAtEntry: Double = Constants.EXCHANGE_RATE
)

data class WorkerDaily(
    val name: String = "",
    val job: String = "عامل",
    val days: Int = 1,
    val dailyWageYER: Double = 0.0,
    val dailyWageSAR: Double = dailyWageYER / Constants.EXCHANGE_RATE,
    val paid: Boolean = false,
    val date: Long = System.currentTimeMillis(),
    val createdBy: String = "مازن",
    val paidAmountSAR: Double = if (paid) dailyWageSAR * days else 0.0,
    val paidAmountYER: Double = if (paid) dailyWageYER * days else 0.0,
    val exchangeRateAtEntry: Double = Constants.EXCHANGE_RATE
)

data class BuildingStage(val name: String = "", var progress: Int = 0, var images: List<String> = emptyList(), val location: String = "")
