package com.hasabi.app2024

import java.util.Calendar
import java.util.UUID

/** A single money movement as entered, with its original currency and ledger date. */
data class ExpenseRow(
    val name: String,
    val amount: Double,
    val currency: String,
    val whenText: String,
    val category: String,
    val trader: String = "",
    val createdBy: String = "مازن",
    val date: Long = System.currentTimeMillis(),
    val id: String = UUID.randomUUID().toString(),
    val paidAmount: Double = amount,
    val exchangeRateAtEntry: Double = Constants.EXCHANGE_RATE
)

data class CurrencyBalances(val sar: Double, val yer: Double, val exchangeRate: Double = Constants.EXCHANGE_RATE) {
    val totalInSar: Double get() = sar + Constants.yerToSar(yer, exchangeRate)
    val totalInYer: Double get() = Constants.sarToYer(sar, exchangeRate) + yer
}

data class BudgetSummary(
    val totalFundingSar: Double,
    val spentToDateSar: Double,
    val remainingSar: Double
) {
    val spentPercent: Double
        get() = if (totalFundingSar > 0.0) (spentToDateSar / totalFundingSar * 100.0).coerceAtLeast(0.0) else 0.0
    val progress: Float get() = (spentPercent / 100.0).toFloat().coerceIn(0f, 1f)
}

data class MonthlyFinancialSummary(
    val sentSarEquivalent: Double,
    val sentCount: Int,
    val receivedSarEquivalent: Double,
    val receivedCount: Int,
    val pendingCount: Int,
    val expensesSarEquivalent: Double,
    val purchasesSarEquivalent: Double,
    val wagesSarEquivalent: Double,
    val familySarEquivalent: Double,
    val netSarEquivalent: Double
)

object LedgerTotals {
    // A fresh installation starts at zero; received transfers add the first recorded funding.
    const val OPENING_SAR = 0.0
    const val OPENING_YER = 0.0

    fun balances(expenses: List<ExpenseRow>, transfers: List<Hawala>, exchangeRate: Double = Constants.EXCHANGE_RATE): CurrencyBalances {
        val receivedSar = transfers.filter { it.received && it.receivedCurrency == "SAR" }.sumOf { it.receivedAmount }
        val receivedYer = transfers.filter { it.received && it.receivedCurrency == "YER" }.sumOf { it.receivedAmount }
        val spentSar = expenses.filter { it.currency == "SAR" }.sumOf { it.paidAmount }
        val spentYer = expenses.filter { it.currency == "YER" }.sumOf { it.paidAmount }
        return CurrencyBalances(
            sar = OPENING_SAR + receivedSar - spentSar,
            yer = OPENING_YER + receivedYer - spentYer,
            exchangeRate = exchangeRate
        )
    }

    /** Funded ledger balance minus all recorded expenses, compared in SAR at the fixed exchange rate. */
    fun budgetSummary(expenses: List<ExpenseRow>, transfers: List<Hawala>, exchangeRate: Double = Constants.EXCHANGE_RATE): BudgetSummary {
        val receivedSarEquivalent = transfers.filter { it.received }.sumOf {
            if (it.receivedCurrency == "YER") Constants.yerToSar(it.receivedAmount, it.receivedExchangeRate) else it.receivedAmount
        }
        val funding = OPENING_SAR + Constants.yerToSar(OPENING_YER, exchangeRate) + receivedSarEquivalent
        val spent = expenses.sumOf { sarEquivalent(it, exchangeRate) }
        return BudgetSummary(totalFundingSar = funding, spentToDateSar = spent, remainingSar = funding - spent)
    }

    fun thisMonth(expenses: List<ExpenseRow>, transfers: List<Hawala>, exchangeRate: Double = Constants.EXCHANGE_RATE): MonthlyFinancialSummary {
        val sentThisMonth = transfers.filter { sameMonth(it.date) }
        val receivedThisMonth = transfers.filter {
            it.received && sameMonth(if (it.receivedAt > 0L) it.receivedAt else it.date)
        }
        val monthExpenses = expenses.filter { sameMonth(it.date) }
        val totalExpenses = monthExpenses.sumOf { sarEquivalent(it, exchangeRate) }
        val paidExpenses = monthExpenses.sumOf { if (it.currency == "YER") Constants.yerToSar(it.paidAmount, it.exchangeRateAtEntry) else it.paidAmount }
        val purchases = monthExpenses.filterNot { isFamily(it) || isWage(it) }.sumOf { sarEquivalent(it, exchangeRate) }
        val wages = monthExpenses.filter { isWage(it) }.sumOf { sarEquivalent(it, exchangeRate) }
        val family = monthExpenses.filter { isFamily(it) }.sumOf { sarEquivalent(it, exchangeRate) }
        val receivedEquivalent = receivedThisMonth.sumOf {
            if (it.receivedCurrency == "YER") Constants.yerToSar(it.receivedAmount, it.receivedExchangeRate) else it.receivedAmount
        }
        return MonthlyFinancialSummary(
            sentSarEquivalent = sentThisMonth.sumOf { it.amountSAR },
            sentCount = sentThisMonth.size,
            receivedSarEquivalent = receivedEquivalent,
            receivedCount = receivedThisMonth.size,
            pendingCount = sentThisMonth.count { !it.received },
            expensesSarEquivalent = totalExpenses,
            purchasesSarEquivalent = purchases,
            wagesSarEquivalent = wages,
            familySarEquivalent = family,
            netSarEquivalent = receivedEquivalent - paidExpenses
        )
    }

    fun sarEquivalent(row: ExpenseRow, exchangeRate: Double = Constants.EXCHANGE_RATE): Double =
        if (row.currency == "YER") Constants.yerToSar(row.amount, row.exchangeRateAtEntry.takeIf { it > 0.0 } ?: exchangeRate) else row.amount

    private fun isFamily(row: ExpenseRow): Boolean = row.category == "مصاريف أهل" || row.category == "مصاريف"
    private fun isWage(row: ExpenseRow): Boolean = row.category == "أجور" || row.category == "رواتب"

    private fun sameMonth(timestamp: Long): Boolean {
        val now = Calendar.getInstance()
        val entry = Calendar.getInstance().apply { timeInMillis = timestamp }
        return now.get(Calendar.YEAR) == entry.get(Calendar.YEAR) &&
            now.get(Calendar.MONTH) == entry.get(Calendar.MONTH)
    }
}
