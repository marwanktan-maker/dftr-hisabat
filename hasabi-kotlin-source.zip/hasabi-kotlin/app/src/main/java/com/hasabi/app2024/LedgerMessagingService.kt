package com.hasabi.app2024

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class LedgerMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val app = FirebaseApp.getApps(this).firstOrNull() ?: return
        if (FirebaseAuth.getInstance(app).currentUser != null) {
            FirebaseMessaging.getInstance(app).subscribeToTopic(Constants.LEDGER_NOTIFICATIONS_TOPIC)
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val event = message.data["type"].orEmpty()
        val title = message.notification?.title ?: when (event) {
            "transfer_received" -> "تم تأكيد استلام الحوالة"
            "expense_created" -> "تم تسجيل مصروف جديد"
            else -> "تم تسجيل حوالة جديدة"
        }
        val body = message.notification?.body ?: "افتح دفتر حسابات لمراجعة التفاصيل."
        showLedgerNotification(this, title, body)
    }
}

fun showLedgerNotification(context: Context, title: String, body: String) {
    ensureLedgerNotificationChannel(context)
    val openApp = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
    }
    val notificationId = (System.currentTimeMillis() and 0x7fffffff).toInt()
    val pendingIntent = PendingIntent.getActivity(
        context,
        notificationId,
        openApp,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val notification = NotificationCompat.Builder(context, "ledger_events")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle(title)
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
        .setAutoCancel(true)
        .setContentIntent(pendingIntent)
        .build()
    try {
        NotificationManagerCompat.from(context).notify(notificationId, notification)
    } catch (_: SecurityException) {
        // قد يرفض المستخدم إذن الإشعارات على Android 13 وما بعده.
    }
}

fun ensureLedgerNotificationChannel(context: Context) {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            "ledger_events",
            "تنبيهات الحسابات",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "تنبيه عند تسجيل حوالة أو مصروف جديد"
            enableVibration(true)
        }
        manager.createNotificationChannel(channel)
    }
}

fun subscribeToLedgerNotifications(context: Context) {
    val app = FirebaseApp.getApps(context).firstOrNull() ?: return
    if (FirebaseAuth.getInstance(app).currentUser == null) return
    val messaging = FirebaseMessaging.getInstance(app)
    messaging.unsubscribeFromTopic("hasabi_transfer_events")
    messaging.subscribeToTopic(Constants.LEDGER_NOTIFICATIONS_TOPIC)
}

fun unsubscribeFromLedgerNotifications(context: Context) {
    val app = FirebaseApp.getApps(context).firstOrNull() ?: return
    val messaging = FirebaseMessaging.getInstance(app)
    messaging.unsubscribeFromTopic(Constants.LEDGER_NOTIFICATIONS_TOPIC)
    messaging.unsubscribeFromTopic("hasabi_transfer_events")
}
