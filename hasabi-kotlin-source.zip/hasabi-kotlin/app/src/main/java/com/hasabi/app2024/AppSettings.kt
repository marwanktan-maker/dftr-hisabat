package com.hasabi.app2024

data class AppSettings(
    val exchangeRate: Double = Constants.EXCHANGE_RATE,
    val budgetAlertSar: Double = Constants.DEFAULT_BUDGET_ALERT_SAR,
    val familyLimitSar: Double = Constants.FAMILY_MONTHLY_LIMIT_SAR,
    val expenseTypes: List<String> = Constants.DEFAULT_EXPENSE_TYPES,
    val lastUpdateBy: String = "",
    val lastUpdateTime: Long = 0L
)
