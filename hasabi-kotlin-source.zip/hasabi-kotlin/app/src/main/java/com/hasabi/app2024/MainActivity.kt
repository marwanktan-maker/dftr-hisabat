package com.hasabi.app2024

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.material3.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.location.LocationServices
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat
import java.util.UUID

private val Green = Color(0xFF2E7D32)
private val LightGreen = Color(0xFFA5D6A7)
private val IconBg = Color(0xFFE8F5E9)
private val DarkGreen = Color(0xFF1B5E20)
private val ExpenseRed = Color(0xFF8D2A2A)
private val ProgressGreen = Color(0xFF00C853)
private val PageWhite = Color.White
private val AppTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 40.sp),
    displayMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
    displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 30.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 24.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp)
)
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp), small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(20.dp), extraLarge = RoundedCornerShape(24.dp)
)

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (FirebaseApp.getApps(this).isNotEmpty()) {
            runCatching {
                val appCheck = FirebaseAppCheck.getInstance()
                if (BuildConfig.DEBUG) {
                    val factory = Class.forName("com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory")
                        .getMethod("getInstance").invoke(null) as com.google.firebase.appcheck.AppCheckProviderFactory
                    appCheck.installAppCheckProviderFactory(factory)
                } else {
                    appCheck.installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance())
                }
            }
        }
        ensureLedgerNotificationChannel(this)
        setContent { DaftarApp() }
    }
}

@Composable
private fun DaftarApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("hasabi-local", 0).also { clearLocalHistoryOnce(it) } }
    val restoredSessionUser = remember {
        val savedName = prefs.getString("current_user", prefs.getString("user", "")).orEmpty()
        savedName.takeIf { it.isNotBlank() && hasFirebaseTeamSession(context, it) }.orEmpty()
    }
    var biometricEnabled by remember { mutableStateOf(prefs.getBoolean("biometric_enabled", false) && restoredSessionUser.isNotBlank())}
    var biometricLockedUser by remember { mutableStateOf(if (biometricEnabled) restoredSessionUser else "") }
    var currentUser by remember { mutableStateOf(if (biometricEnabled) "" else restoredSessionUser) }
    var currentRole by remember { mutableStateOf("") }
    var biometricPromptNonce by remember { mutableIntStateOf(0) }
    var biometricMessage by remember { mutableStateOf("") }
    var biometricPromptActive by remember { mutableStateOf(false) }
    var showBiometricSetup by remember { mutableStateOf(false) }
    val lifecycleOwner = context as? LifecycleOwner
    var appVisible by remember { mutableStateOf(lifecycleOwner?.lifecycle?.currentState?.isAtLeast(Lifecycle.State.STARTED) == true) }
    val latestUser = rememberUpdatedState(currentUser)
    val latestBiometricEnabled = rememberUpdatedState(biometricEnabled)
    val latestPromptActive = rememberUpdatedState(biometricPromptActive)
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var showPdfSelection by remember { mutableStateOf(false) }
    var showAdminPanel by remember { mutableStateOf(false) }
    var exitAction by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selectedLoginName by remember { mutableStateOf("") }
    var expenseRows by remember { mutableStateOf(loadExpenses(prefs.getString("expenses", null))) }
    var customExpenses by remember { mutableStateOf(mutableListOf<Expense>()) }
    var transfers by remember { mutableStateOf(LedgerPersistence.loadTransfers(prefs.getString("transfers", null))) }
    var workerRecords by remember { mutableStateOf(LedgerPersistence.loadWorkers(prefs.getString("workers", null))) }
    var appSettings by remember { mutableStateOf(AppSettings()) }
    var syncStatus by remember { mutableStateOf("محلي — إعداد Firebase غير مكتمل") }
    val latestTransfers = rememberUpdatedState(transfers)
    val latestExpenses = rememberUpdatedState(expenseRows)
    val latestWorkerRecords = rememberUpdatedState(workerRecords)
    val balances = remember(expenseRows, transfers, appSettings.exchangeRate) { LedgerTotals.balances(expenseRows, transfers, appSettings.exchangeRate) }
    val monthlyTotals = remember(expenseRows, transfers, appSettings.exchangeRate) { LedgerTotals.thisMonth(expenseRows, transfers, appSettings.exchangeRate) }
    val budgetTotals = remember(expenseRows, transfers, appSettings.exchangeRate) { LedgerTotals.budgetSummary(expenseRows, transfers, appSettings.exchangeRate) }
    DisposableEffect(currentUser) {
        if (currentUser.isBlank()) {
            syncStatus = "محلي"
            onDispose { }
        } else if (!hasFirebaseTeamSession(context, currentUser)) {
            syncStatus = if (FirebaseApp.getApps(context).isEmpty()) "محلي — Firebase غير مهيأ" else "محلي — أعد الدخول لتفعيل المزامنة"
            onDispose { }
        } else {
            syncStatus = "جار الاتصال بـ Firestore…"
            val transferListener = listenTransfers(context, { remote ->
                val remoteIds = remote.map { it.id }.toSet()
                val merged = (latestTransfers.value.filter { it.id !in remoteIds } + remote).distinctBy { it.id }.sortedBy { it.date }
                transfers = merged.toMutableList()
                LedgerPersistence.saveTransfers(prefs, merged)
            }, { status -> syncStatus = status })
            val expenseListener = listenExpenseRows(context, { remote ->
                val remoteIds = remote.map { it.id }.toSet()
                val merged = (latestExpenses.value.filter { it.id !in remoteIds } + remote).distinctBy { it.id }.sortedByDescending { it.date }
                expenseRows = merged
                saveExpenses(prefs, merged)
            }, { status -> syncStatus = status })
            val workerListener = listenWorkerRecords(context, { remote ->
                val remoteKeys = remote.map { "${it.date}-${it.name}-${it.job}" }.toSet()
                val merged = (latestWorkerRecords.value.filter { "${it.date}-${it.name}-${it.job}" !in remoteKeys } + remote)
                    .distinctBy { "${it.date}-${it.name}-${it.job}" }.sortedBy { it.date }
                workerRecords = merged.toMutableList()
                LedgerPersistence.saveWorkers(prefs, merged)
            }, { status -> syncStatus = status })
            val settingsListener = listenAppSettings(context, { settings -> appSettings = settings }, { status -> syncStatus = status })
            if (transferListener == null || expenseListener == null || workerListener == null || settingsListener == null) syncStatus = "تعذر بدء مزامنة Firestore"
            onDispose {
                transferListener?.remove()
                expenseListener?.remove()
                workerListener?.remove()
                settingsListener?.remove()
            }
        }
    }
    var foundationProgress by remember { mutableIntStateOf(prefs.getInt("foundationProgress", 0)) }
    var stageProgress by remember { mutableIntStateOf(prefs.getInt("stageProgress", 0)) }
    val familyMonthKey = remember { SimpleDateFormat("yyyy-MM", Locale.US).format(Date()) }
    var householdSar by remember { mutableDoubleStateOf(prefs.getFloat("family-$familyMonthKey", 0.0f).toDouble()) }
    val syncedHouseholdSar = remember(expenseRows, familyMonthKey, appSettings.exchangeRate) {
        val monthFormat = SimpleDateFormat("yyyy-MM", Locale.US)
        expenseRows.filter { (it.category == "مصاريف أهل" || it.category == "مصاريف") && monthFormat.format(Date(it.date)) == familyMonthKey }
            .sumOf { LedgerTotals.sarEquivalent(it, appSettings.exchangeRate) }
    }
    LaunchedEffect(syncedHouseholdSar, familyMonthKey) {
        householdSar = syncedHouseholdSar
        prefs.edit().putFloat("family-$familyMonthKey", syncedHouseholdSar.toFloat()).apply()
    }
    var missingItems by remember { mutableStateOf(mutableListOf<String>()) }
    var comparison by remember { mutableStateOf(mutableListOf<String>()) }
    var searchQuery by remember { mutableStateOf("") }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val client = LocationServices.getFusedLocationProviderClient(context)
            try {
                @Suppress("MissingPermission")
                client.lastLocation.addOnSuccessListener { loc ->
                    toast = if (loc != null) "تم تسجيل الموقع: ${loc.latitude}, ${loc.longitude}" else "تعذر تحديد الموقع حالياً"
                }
            } catch (_: SecurityException) { toast = "لم يُمنح إذن الموقع" }
        } else toast = "يلزم إذن الموقع لتسجيل GPS"
    }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) toast = "يمكن تفعيل تنبيهات الحسابات لاحقاً من إعدادات Android"
    }
    DisposableEffect(lifecycleOwner) {
        val owner = lifecycleOwner
        if (owner == null) {
            onDispose { }
        } else {
            val observer = LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_START -> appVisible = true
                    Lifecycle.Event.ON_STOP -> {
                        appVisible = false
                        val activeUser = latestUser.value
                        if (latestBiometricEnabled.value && !latestPromptActive.value && activeUser.isNotBlank()) {
                            biometricLockedUser = activeUser
                            currentUser = ""
                            biometricMessage = ""
                        }
                    }
                    else -> Unit
                }
            }
            owner.lifecycle.addObserver(observer)
            onDispose { owner.lifecycle.removeObserver(observer) }
        }
    }

    LaunchedEffect(currentUser, biometricLockedUser, biometricPromptNonce) {
        if (currentUser.isBlank() && biometricLockedUser.isBlank()) {
            val savedName = prefs.getString("user", "").orEmpty()
            if (savedName.isNotBlank()) {
                prefs.edit().remove("user").remove("current_user").remove("current_role").putBoolean("isLoggedIn", false).putBoolean("biometric_enabled", false).apply()
                biometricEnabled = false
                signOutFirebaseTeam(context)
            }
        } else if (currentUser.isNotBlank()) {
            subscribeToLedgerNotifications(context)
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(currentUser) {
        if (currentUser.isBlank()) {
            currentRole = ""
        } else {
            loadVerifiedTeamRole(context, currentUser) { role ->
                currentRole = role.orEmpty()
                if (role != null) prefs.edit().putString("current_user", currentUser).putString("current_role", role).putBoolean("isLoggedIn", true).apply()
            }
        }
    }

    LaunchedEffect(biometricLockedUser, biometricPromptNonce, appVisible) {
        val userToUnlock = biometricLockedUser
        if (userToUnlock.isNotBlank() && appVisible && !biometricPromptActive) {
            if (!isStrongBiometricAvailable(context)) {
                biometricMessage = "لا توجد بصمة قوية متاحة. استخدم كلمة السر للمتابعة أو سجّل بصمة من إعدادات Android."
            } else {
                val activity = context as? FragmentActivity
                if (activity == null) {
                    biometricMessage = "تعذر فتح نافذة البصمة على هذا الجهاز."
                } else {
                    biometricPromptActive = true
                    requestBiometricAuthentication(
                        activity = activity,
                        title = "فتح دفتر حسابات",
                        negativeButtonText = "الدخول بكلمة السر",
                        onSuccess = {
                            biometricPromptActive = false
                            currentUser = userToUnlock
                            biometricLockedUser = ""
                            biometricMessage = ""
                        },
                        onPasswordFallback = {
                            biometricPromptActive = false
                            biometricLockedUser = ""
                            biometricEnabled = false
                            biometricMessage = ""
                            prefs.edit().remove("user").remove("current_user").remove("current_role").putBoolean("isLoggedIn", false).putBoolean("biometric_enabled", false).apply()
                            signOutFirebaseTeam(context)
                        },
                        onError = { biometricPromptActive = false; biometricMessage = it }
                    )
                }
            }
        }
    }

    BackHandler(enabled = exitAction.isBlank() && !showAdd && !showPdfSelection && dialog.isBlank() && toast.isBlank() && !showBiometricSetup && !biometricPromptActive) {
        exitAction = "app"
    }

    val appColors = if (dark) darkColorScheme(
        primary = LightGreen, onPrimary = DarkGreen, secondary = ProgressGreen,
        background = Color(0xFF101510), surface = Color(0xFF192019), onSurface = Color(0xFFEAF1EA),
        surfaceVariant = Color(0xFF253026), onSurfaceVariant = LightGreen, error = Color(0xFFEF9A9A)
    ) else lightColorScheme(
        primary = Green, onPrimary = Color.White, secondary = ProgressGreen,
        background = PageWhite, surface = Color.White, onSurface = Color(0xFF172018),
        surfaceVariant = IconBg, onSurfaceVariant = DarkGreen, error = ExpenseRed
    )
    MaterialTheme(colorScheme = appColors, typography = AppTypography, shapes = AppShapes) {
        val view = LocalView.current
        SideEffect {
            // Android owns the real clock, connectivity and system notifications; never draw a fake status bar.
            (view.context as? Activity)?.window?.let { window ->
                window.statusBarColor = appColors.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
            }
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                if (currentUser.isBlank()) {
                    if (biometricLockedUser.isNotBlank()) {
                        BiometricUnlockScreen(
                            userName = biometricLockedUser,
                            message = biometricMessage,
                            onRetry = { biometricMessage = ""; biometricPromptNonce++ },
                            onUsePassword = {
                                biometricLockedUser = ""
                                biometricEnabled = false
                                prefs.edit().remove("user").remove("current_user").remove("current_role").putBoolean("isLoggedIn", false).putBoolean("biometric_enabled", false).apply()
                                signOutFirebaseTeam(context)
                            }
                        )
                    } else PasswordScreen(
                        userName = selectedLoginName,
                        onUserName = { selectedLoginName = it },
                        password = password,
                        onPassword = { value -> password = value.filter { it.code < 128 && it.isLetterOrDigit() }.take(64) },
                        onEnter = {
                            val code = password
                            val name = selectedLoginName
                            when {
                                name !in Constants.TEAM_MEMBERS -> toast = "اختر الاسم أولاً"
                                code.length < 5 -> toast = "أدخل كلمة السر كاملة"
                                FirebaseApp.getApps(context).isEmpty() -> {
                                    password = ""
                                    toast = "يلزم إعداد Firebase للتحقق الآمن من الاسم وكلمة السر"
                                }
                                else -> {
                                    password = ""
                                    toast = "جارٍ التحقق من بيانات الدخول…"
                                    authenticateTeamPassword(context, code, name) { authenticated, role, error ->
                                        if (authenticated && (role == "ADMIN" || role == "USER")) {
                                            currentUser = name
                                            currentRole = role.orEmpty()
                                            prefs.edit().putString("user", name).putString("current_user", name)
                                                .putString("current_role", role).putBoolean("isLoggedIn", true).apply()
                                            toast = "تم تسجيل الدخول والمزامنة"
                                            if (!biometricEnabled) {
                                                if (isStrongBiometricAvailable(context)) {
                                                    toast = ""
                                                    showBiometricSetup = true
                                                } else toast = "تم تسجيل الدخول. سجّل بصمة في إعدادات Android لتفعيل فتح التطبيق بها."
                                            }
                                        } else {
                                            toast = "تعذر التحقق من بيانات الدخول؛ تحقق من الاتصال وإعداد Firebase${error?.let { ": $it" } ?: ""}"
                                        }
                                    }
                                }
                            }
                        },
                        message = toast
                    )
                } else {
                    Scaffold(
                        containerColor = MaterialTheme.colorScheme.background,
                        bottomBar = {
                            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                                val labels = listOf("الرئيسية", "المشاريع", "إضافة", "التقارير", "الحساب")
                                val icons = listOf(Icons.Default.Home, Icons.Default.Apartment, Icons.Default.Add, Icons.Default.BarChart, Icons.Default.Person)
                                labels.forEachIndexed { index, label ->
                                    NavigationBarItem(
                                        selected = tab == index,
                                        onClick = { if (index == 2) showAdd = true else tab = index },
                                        icon = { Icon(icons[index], label, tint = if (tab == index) Green else MaterialTheme.colorScheme.onSurfaceVariant, modifier = if (index == 2) Modifier.size(30.dp) else Modifier.size(22.dp)) },
                                        label = {
                                            Text(
                                                text = label,
                                                fontFamily = FontFamily.SansSerif,
                                                fontSize = 13.sp,
                                                fontWeight = if (tab == index) FontWeight.SemiBold else FontWeight.Medium,
                                                letterSpacing = 0.1.sp,
                                                maxLines = 1
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Green,
                                            selectedTextColor = Green,
                                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                            indicatorColor = IconBg
                                        )
                                    )
                                }
                            }
                        },
                    ) { padding ->
                        Box(Modifier.padding(padding)) {
                        Crossfade(targetState = tab, label = "main-tab") { selectedTab ->
                        when (selectedTab) {
                            0 -> HomeScreen(
                                userName = currentUser,
                                role = currentRole,
                                rows = expenseRows.filter { searchQuery.isBlank() || it.name.contains(searchQuery, true) || it.category.contains(searchQuery, true) },
                                foundationProgress = foundationProgress,
                                stageProgress = stageProgress,
                                searchText = searchQuery,
                                onSearch = { searchQuery = it },
                                onAdd = { showAdd = true },
                                onNotify = { dialog = "التنبيهات" },
                                balances = balances,
                                budget = budgetTotals,
                                monthly = monthlyTotals,
                                syncStatus = syncStatus,
                                exchangeRate = appSettings.exchangeRate,
                                budgetAlertSar = appSettings.budgetAlertSar
                            )
                            1 -> ProjectsScreen(
                                foundationProgress = foundationProgress,
                                stageProgress = stageProgress,
                                onFoundationProgress = { foundationProgress = it; prefs.edit().putInt("foundationProgress", it).apply() },
                                onProgress = { stageProgress = it; prefs.edit().putInt("stageProgress", it).apply() },
                                onGps = { permission.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
                            )
                            3 -> ReportsScreen(
                                currentUser = currentUser,
                                isAdmin = currentRole == "ADMIN",
                                rows = expenseRows,
                                transfers = transfers,
                                workers = workerRecords,
                                householdSar = householdSar,
                                balances = balances,
                                budget = budgetTotals,
                                monthly = monthlyTotals,
                                exchangeRate = appSettings.exchangeRate,
                                familyLimitSar = appSettings.familyLimitSar,
                                canMarkReceived = currentUser == "مازن",
                                onPdf = { showPdfSelection = true },
                                onCalculator = { dialog = "الحاسبة" },
                                onToggleReceived = { dialog = "استلام حوالة" },
                                onToggleWorkerPaid = { index ->
                                    val worker = workerRecords.getOrNull(index)
                                    if (worker != null && !worker.paid) {
                                        val fullyPaid = worker.copy(
                                            paid = true,
                                            paidAmountSAR = worker.dailyWageSAR * worker.days,
                                            paidAmountYER = worker.dailyWageYER * worker.days
                                        )
                                        workerRecords = workerRecords.mapIndexed { i, item -> if (i == index) fullyPaid else item }.toMutableList()
                                        LedgerPersistence.saveWorkers(prefs, workerRecords)
                                        syncWorkerRecord(context, fullyPaid)

                                        val updatedRows = expenseRows.map { row ->
                                            if (row.category == "أجور" && row.trader == worker.name && row.createdBy == worker.createdBy && row.date == worker.date) {
                                                row.copy(paidAmount = row.amount)
                                            } else row
                                        }
                                        if (updatedRows != expenseRows) {
                                            expenseRows = updatedRows
                                            saveExpenses(prefs, expenseRows)
                                            expenseRows.filter { it.category == "أجور" && it.trader == worker.name && it.createdBy == worker.createdBy && it.date == worker.date }
                                                .forEach { syncExpenseRow(context, it) }
                                        }
                                    }
                                }
                            )
                            else -> AccountScreen(currentUser, currentRole, appSettings, dark, { dark = it; prefs.edit().putBoolean("dark", it).apply() }, onAdminPanel = { showAdminPanel = true }, onTool = { action -> if (action == "PDF" || action == "مشاركة واتساب") showPdfSelection = true else dialog = action }, onLogout = { exitAction = "logout" })
                        }
                        }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AlertDialog(
        onDismissRequest = { showAdd = false }, title = { Text("إضافة سجل") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            (if (currentUser == "مازن") listOf("استلام حوالة", "شراء مواد", "أجرة/خدمة", "مصاريف أهل") else listOf("إرسال حوالة", "شراء مواد", "أجرة/خدمة", "مصاريف أهل")).forEach { item ->
                OutlinedButton(onClick = { showAdd = false; dialog = item }, modifier = Modifier.fillMaxWidth()) { Text(item) }
            }
        } }, confirmButton = { TextButton(onClick = { showAdd = false }) { Text("إغلاق") } }
    )

    when (dialog) {
        "إرسال حوالة", "استلام حوالة", "شراء مواد", "أجرة/خدمة", "مصاريف أهل" -> RecordDialog(dialog, currentUser, appSettings.exchangeRate, appSettings.expenseTypes, onDismiss = { dialog = "" }, onSave = { title, amount, detail, currency, paidText ->
            val value = amount.toDoubleOrNull() ?: 0.0
            val paidValue = paidText.toDoubleOrNull() ?: value
            val amountSar = if (currency == "YER") Constants.yerToSar(value, appSettings.exchangeRate) else value
            val amountYer = if (currency == "YER") value else Constants.sarToYer(value, appSettings.exchangeRate)
            val entryDate = System.currentTimeMillis()
            if (value <= 0) toast = "أدخل مبلغاً صحيحاً"
            else if (paidValue < 0.0 || paidValue > value) toast = "يجب أن يكون المدفوع بين صفر وإجمالي المبلغ"
            else if (dialog == "مصاريف أهل" && householdSar + amountSar > appSettings.familyLimitSar) {
                toast = "تم إيقاف المصروف: الحد الشهري ${money(appSettings.familyLimitSar)} SAR"
            } else {
                var resultMessage = "تم حفظ السجل على الجهاز"
                when (dialog) {
                    "شراء مواد" -> {
                        val e = Expense(id = UUID.randomUUID().toString(), type = title, trader = detail, amountYER = amountYer, amountSAR = amountSar, date = entryDate, createdBy = currentUser, exchangeRateAtEntry = appSettings.exchangeRate)
                        customExpenses.add(e)
                        val row = ExpenseRow(title, value, currency, "الآن", "مواد بناء", detail, currentUser, entryDate, e.id, paidAmount = paidValue, exchangeRateAtEntry = appSettings.exchangeRate)
                        expenseRows = expenseRows + row
                        saveExpenses(prefs, expenseRows)
                        syncExpenseRow(context, row)
                    }
                    "مصاريف أهل" -> {
                        householdSar += amountSar
                        prefs.edit().putFloat("family-$familyMonthKey", householdSar.toFloat()).apply()
                        val row = ExpenseRow(title, value, currency, "الآن", "مصاريف أهل", "", currentUser, entryDate, paidAmount = value, exchangeRateAtEntry = appSettings.exchangeRate)
                        expenseRows = expenseRows + row
                        saveExpenses(prefs, expenseRows)
                        syncExpenseRow(context, row)
                    }
                    "إرسال حوالة" -> {
                        val transfer = Hawala(id = LedgerPersistence.transferDocumentId(title), number = title, amountSAR = amountSar, amountYER = amountYer, from = currentUser, recipient = "مازن", date = entryDate, createdBy = currentUser, received = false, exchangeRateAtEntry = appSettings.exchangeRate)
                        transfers = (transfers + transfer).toMutableList()
                        LedgerPersistence.saveTransfers(prefs, transfers)
                        syncTransferRecord(context, transfer)
                    }
                    "استلام حوالة" -> {
                        val existing = transfers.indexOfFirst { it.number.equals(title, ignoreCase = true) }
                        if (existing >= 0) {
                            val transfer = transfers[existing]
                            if (transfer.received) {
                                resultMessage = "الحوالة مسجلة كمستلمة مسبقاً."
                            } else {
                                val amountMatches = kotlin.math.abs(transfer.amountSAR - amountSar) < 0.01
                                val senderMatches = detail.isNotBlank() && transfer.from.equals(detail.trim(), ignoreCase = true)
                                if (!amountMatches || !senderMatches) {
                                    resultMessage = "لم يتم التأكيد: أدخل اسم المرسل الصحيح وتأكد من مطابقة المبلغ ورقم الحوالة."
                                } else {
                                    transfers = transfers.mapIndexed { i, item -> if (i == existing) item.copy(received = true, receivedCurrency = currency, receivedAmount = value, receivedAt = entryDate, receivedExchangeRate = appSettings.exchangeRate) else item }.toMutableList()
                                    LedgerPersistence.saveTransfers(prefs, transfers)
                                    transfers.firstOrNull { it.id == transfer.id }?.let { syncTransferRecord(context, it) }
                                }
                            }
                        } else {
                            resultMessage = "لا توجد حوالة بهذا الرقم مسجلة للفريق؛ اطلب من المرسل تسجيلها أولاً."
                        }
                    }
                    "أجرة/خدمة" -> {
                        val job = detail.ifBlank { "عامل" }
                        val paidSar = if (currency == "YER") Constants.yerToSar(paidValue, appSettings.exchangeRate) else paidValue
                        val paidYer = if (currency == "YER") paidValue else Constants.sarToYer(paidValue, appSettings.exchangeRate)
                        workerRecords = (workerRecords + WorkerDaily(
                            title, job, 1, amountYer, amountSar, paid = paidValue >= value,
                            date = entryDate, createdBy = currentUser,
                            paidAmountSAR = paidSar, paidAmountYER = paidYer, exchangeRateAtEntry = appSettings.exchangeRate
                        )).toMutableList()
                        LedgerPersistence.saveWorkers(prefs, workerRecords)
                        workerRecords.lastOrNull()?.let { syncWorkerRecord(context, it) }
                        val wageRow = ExpenseRow("أجرة $job — $title", value, currency, "الآن", "أجور", title, currentUser, entryDate, paidAmount = paidValue, exchangeRateAtEntry = appSettings.exchangeRate)
                        expenseRows = expenseRows + wageRow
                        saveExpenses(prefs, expenseRows)
                        syncExpenseRow(context, wageRow)
                    }
                }
                toast = resultMessage
            }
            dialog = ""
        })
        "إعداد البصمة" -> {
            dialog = ""
            if (biometricEnabled) {
                biometricEnabled = false
                prefs.edit().putBoolean("biometric_enabled", false).apply()
                toast = "تم إيقاف فتح التطبيق بالبصمة."
            } else if (isStrongBiometricAvailable(context)) {
                toast = ""
                showBiometricSetup = true
            } else {
                toast = "سجّل بصمة قوية من إعدادات Android أولاً."
            }
        }
        "التنبيهات" -> SimpleDialog("التنبيهات", if (remainingSar(expenseRows, transfers, appSettings.exchangeRate) < appSettings.budgetAlertSar) "تنبيه: الرصيد المتبقي أقل من ${money(appSettings.budgetAlertSar)} SAR" else "لا توجد تنبيهات جديدة", { dialog = "" })
        "الحاسبة" -> CalculatorDialog(appSettings.exchangeRate) { dialog = "" }
        "قائمة النواقص", "مقارنة الأسعار" -> TextListDialog(dialog, if (dialog == "قائمة النواقص") missingItems else comparison, { value ->
            if (dialog == "قائمة النواقص") missingItems.add(value) else comparison.add(value)
        }, { dialog = "" })
        "تحديث" -> { LaunchedEffect(dialog) { toast = "تم تحديث العرض من البيانات المحلية"; dialog = "" } }
        "نسخة احتياطية" -> BackupDialog({ dialog = "" })
        "استعادة" -> RestoreDialog({ dialog = "" })
        "PDF" -> { LaunchedEffect(dialog) { createPdf(context, expenseRows); toast = "تم حفظ التقرير PDF"; dialog = "" } }
        "مشاركة واتساب" -> { LaunchedEffect(dialog) { shareWhatsApp(context, expenseRows); dialog = "" } }
        "مصروفات" -> SimpleDialog("مصروفات الأسرة الشهرية", "المسجل لهذا الشهر: ${money(householdSar)} SAR من حد ${money(appSettings.familyLimitSar)} SAR. ${if (householdSar >= appSettings.familyLimitSar) "تم بلوغ الحد" else "المتبقي ${money(appSettings.familyLimitSar-householdSar)} SAR"}", { dialog = "" })
    }

    if (showAdminPanel && currentRole == "ADMIN") {
        AdminSettingsDialog(
            settings = appSettings,
            onDismiss = { showAdminPanel = false },
            onSave = { updated ->
                if (currentRole != "ADMIN") {
                    toast = "صلاحية المسؤول مطلوبة لحفظ الإعدادات."
                } else {
                    syncAppSettings(context, updated, currentUser) { saved, error ->
                        if (saved) {
                            toast = "تم حفظ الإعدادات؛ تتزامن على الأجهزة عند اتصالها بالإنترنت."
                            showAdminPanel = false
                        } else toast = error ?: "تعذر حفظ الإعدادات."
                    }
                }
            }
        )
    }

    if (showPdfSelection) {
        PdfAccountSelectionDialog(
            onDismiss = { showPdfSelection = false },
            onShare = { selectedAccounts ->
                val selectedExpenses = expenseRows.filter { it.createdBy in selectedAccounts }
                val reportExpenses = selectedExpenses.map { row ->
                    val amountSar = if (row.currency == "YER") Constants.yerToSar(row.amount, row.exchangeRateAtEntry) else row.amount
                    val amountYer = if (row.currency == "YER") row.amount else Constants.sarToYer(row.amount, row.exchangeRateAtEntry)
                    val paidSar = if (row.currency == "YER") Constants.yerToSar(row.paidAmount, row.exchangeRateAtEntry) else row.paidAmount
                    val paidYer = if (row.currency == "YER") row.paidAmount else Constants.sarToYer(row.paidAmount, row.exchangeRateAtEntry)
                    ExpenseRowForReport(row.name, row.category, amountSar, amountYer, row.trader, row.createdBy, row.whenText, row.date, paidSar, paidYer, row.currency)
                }
                val selectedTransfers = transfers.filter { it.from in selectedAccounts || it.recipient in selectedAccounts || it.createdBy in selectedAccounts }.distinctBy { it.id }
                val selectedWorkers = workerRecords.filter { it.createdBy in selectedAccounts }
                val thisMonthKey = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
                val familyTotal = selectedExpenses.filter { it.category == "مصاريف أهل" || it.category == "مصاريف" }
                    .filter { SimpleDateFormat("yyyy-MM", Locale.US).format(Date(it.date)) == thisMonthKey }
                    .sumOf { LedgerTotals.sarEquivalent(it, appSettings.exchangeRate) }
                shareDetailedPdf(context, selectedAccounts, reportExpenses, selectedTransfers, selectedWorkers, familyTotal, currentUser, appSettings.exchangeRate, appSettings.familyLimitSar)
                showPdfSelection = false
                toast = "تم إنشاء التقرير وفتح خيارات المشاركة"
            }
        )
    }

    if (exitAction.isNotBlank()) {
        val isLogout = exitAction == "logout"
        AlertDialog(
            onDismissRequest = { exitAction = "" },
            title = { Text(if (isLogout) "تأكيد تسجيل الخروج" else "تأكيد الخروج") },
            text = { Text(if (isLogout) "هل تريد تسجيل الخروج من حساب $currentUser؟" else "هل تريد إغلاق التطبيق؟ ستبقى جلستك محفوظة.") },
            confirmButton = {
                TextButton(onClick = {
                    val action = exitAction
                    exitAction = ""
                    if (action == "logout") {
                        signOutFirebaseTeam(context)
                        prefs.edit().remove("user").remove("current_user").remove("current_role").putBoolean("isLoggedIn", false).putBoolean("biometric_enabled", false).apply()
                        biometricEnabled = false
                        biometricLockedUser = ""
                        currentUser = ""
                        currentRole = ""
                    } else (context as? Activity)?.finish()
                }) { Text("نعم") }
            },
            dismissButton = { TextButton(onClick = { exitAction = "" }) { Text("لا") } }
        )
    }

    if (showBiometricSetup) {
        AlertDialog(
            onDismissRequest = { showBiometricSetup = false },
            title = { Text("تفعيل فتح التطبيق بالبصمة؟") },
            text = { Text("بعد تفعيلها، تحتفظ جلسة Firebase بتسجيل الدخول ويطلب Android بصمتك عند فتح التطبيق مجدداً بدلاً من إعادة كتابة كلمة السر. لا تُحفظ البصمة أو كلمة السر داخل التطبيق.") },
            confirmButton = {
                TextButton(onClick = {
                    showBiometricSetup = false
                    val activity = context as? FragmentActivity
                    if (activity == null) {
                        toast = "تعذر فتح نافذة البصمة."
                    } else {
                        biometricPromptActive = true
                        requestBiometricAuthentication(
                            activity = activity,
                            title = "تأكيد تفعيل البصمة",
                            negativeButtonText = "إلغاء",
                            onSuccess = {
                                biometricPromptActive = false
                                biometricEnabled = true
                                prefs.edit().putBoolean("biometric_enabled", true).apply()
                                toast = "تم تفعيل البصمة. استخدم إعداد البصمة في الحساب لإيقافها."
                            },
                            onPasswordFallback = { biometricPromptActive = false; toast = "لم يتم تفعيل البصمة؛ تبقى الجلسة محفوظة." },
                            onError = { biometricPromptActive = false; toast = "لم يتم تفعيل البصمة: $it" }
                        )
                    }
                }) { Text("تفعيل بالبصمة") }
            },
            dismissButton = { TextButton(onClick = { showBiometricSetup = false }) { Text("لاحقاً") } }
        )
    }
    if (toast.isNotBlank()) AlertDialog(onDismissRequest = { toast = "" }, text = { Text(toast) }, confirmButton = { TextButton(onClick = { toast = "" }) { Text("حسناً") } })
}

@Composable
private fun BiometricUnlockScreen(userName: String, message: String, onRetry: () -> Unit, onUsePassword: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Lock, null, tint = Green, modifier = Modifier.size(64.dp))
        Text("أهلاً $userName", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = DarkGreen)
        Text("الجلسة محفوظة. افتح دفتر حسابات ببصمة الهاتف.", textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("فتح بالبصمة") }
        TextButton(onClick = onUsePassword) { Text("استخدام كلمة السر بدلاً من البصمة") }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun PasswordScreen(
    userName: String,
    onUserName: (String) -> Unit,
    password: String,
    onPassword: (String) -> Unit,
    onEnter: () -> Unit,
    message: String
) {
    var namesExpanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Apartment, null, tint = Green, modifier = Modifier.size(72.dp))
        Text("دفتر حسابات", fontSize = 30.sp, color = DarkGreen, fontWeight = FontWeight.Bold)
        Text("دخول آمن للفريق", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
        Box(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = userName,
                onValueChange = {},
                readOnly = true,
                label = { Text("اسم المستخدم") },
                placeholder = { Text("اختر الاسم") },
                trailingIcon = { IconButton(onClick = { namesExpanded = true }) { Icon(Icons.Default.ArrowDropDown, "اختيار الاسم") } },
                modifier = Modifier.fillMaxWidth().clickable { namesExpanded = true },
                singleLine = true
            )
            DropdownMenu(expanded = namesExpanded, onDismissRequest = { namesExpanded = false }) {
                Constants.TEAM_MEMBERS.forEach { name ->
                    DropdownMenuItem(
                        text = { Text(name) },
                        onClick = { onUserName(name); namesExpanded = false }
                    )
                }
            }
        }
        OutlinedTextField(
            value = password,
            onValueChange = onPassword,
            label = { Text("كلمة السر") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
        )
        Button(onClick = onEnter, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("دخول") }
        Text("مروان • محمد • مازن", color = Green, modifier = Modifier.padding(top = 12.dp))
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp), textAlign = TextAlign.Center)
        Text("بعد أول دخول تبقى الجلسة محفوظة؛ يمكنك تفعيل بصمة الهاتف لفتحها لاحقاً دون إعادة كتابة كلمة السر.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 24.dp))
    }
}

@Composable
private fun HomeScreen(userName: String, role: String, rows: List<ExpenseRow>, foundationProgress: Int, stageProgress: Int, searchText: String, onSearch: (String) -> Unit, onAdd: () -> Unit, onNotify: () -> Unit, balances: CurrencyBalances, budget: BudgetSummary, monthly: MonthlyFinancialSummary, syncStatus: String, exchangeRate: Double, budgetAlertSar: Double) {
    var searching by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onNotify) { Icon(Icons.Default.NotificationsNone, "التنبيهات", tint = Green) }
                IconButton(onClick = { searching = !searching }) { Icon(Icons.Default.Search, "بحث", tint = Green) }
                Spacer(Modifier.weight(1f))
                Text("دفتر حسابات", fontSize = 22.sp, color = DarkGreen, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(42.dp).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) { Icon(Icons.Default.Apartment, null, tint = Color.White) }
            }
            AnimatedVisibility(visible = searching) {
                OutlinedTextField(value = searchText, onValueChange = onSearch, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("ابحث عن مصروف") }, singleLine = true)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row {
                    listOf("م", "م", "ز").forEachIndexed { i, s ->
                        Box(Modifier.padding(end = 3.dp).size(42.dp).border(2.dp, Color.White, CircleShape).clip(CircleShape).background(listOf(Color(0xFFCFD8DC), Color(0xFFB0BEC5), Color(0xFFA5D6A7))[i]), contentAlignment = Alignment.Center) {
                            Text(s, fontWeight = FontWeight.Bold, color = DarkGreen)
                        }
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("مرحباً $userName${if (role == "ADMIN") " (المسؤول)" else ""}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("لوحة التحكم — 3 مستخدمين نشطين", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("مروان • محمد • مازن", fontSize = 13.sp, color = Green)
                    Text("المزامنة: $syncStatus", fontSize = 12.sp, color = if (syncStatus.startsWith("متصل")) Green else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Text("الرصيد الإجمالي", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BalanceCard("SAR", money(balances.sar), "متاح بالريال السعودي", Modifier.weight(1f), true)
                BalanceCard("YER", money(balances.yer), "متاح بالريال اليمني", Modifier.weight(1f), false)
            }
        }
        item { BudgetProgressCard(budget, budgetAlertSar) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = IconBg), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("إجمالي الرصيد المكافئ: ${money(balances.totalInSar)} SAR", fontWeight = FontWeight.Bold, color = DarkGreen)
                    Text("حوالات مرسلة: ${money(monthly.sentSarEquivalent)} SAR • مستلمة فعلياً: ${money(monthly.receivedSarEquivalent)} SAR", fontSize = 12.sp, color = DarkGreen)
                    Text("مصروف الشهر: ${money(monthly.expensesSarEquivalent)} SAR • الصافي: ${money(monthly.netSarEquivalent)} SAR", fontSize = 12.sp, color = DarkGreen)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("المصروفات الأخيرة", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("عرض الكل  ›", color = Green, modifier = Modifier.clickable(onClick = onAdd))
            }
        }
        if (rows.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = IconBg), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("لا توجد سجلات بعد", fontWeight = FontWeight.Bold, color = DarkGreen, fontSize = 17.sp)
                        Text("أضف أول حوالة أو عملية شراء أو أجرة من زر +", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, textAlign = TextAlign.Center)
                        OutlinedButton(onClick = onAdd) { Text("إضافة أول سجل") }
                    }
                }
            }
        } else items(rows) { row -> ExpenseCard(row) }
        item { Text("تقدم مراحل البناء", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp)) }
        item { StageBar("مرحلة الأساسات", foundationProgress, if (foundationProgress == 100) "مكتمل" else if (foundationProgress == 0) "لم تبدأ" else "قيد التنفيذ") }
        item { StageBar("مرحلة التشطيب", stageProgress, if (stageProgress == 0) "لم تبدأ" else if (stageProgress <= 20) "قيد الانتظار" else "قيد التنفيذ") }
        item {
            Text("سعر الصرف الحالي: 1 SAR = ${money(exchangeRate)} YER", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp))
        }
    }
}


@Composable
private fun BudgetProgressCard(budget: BudgetSummary, budgetAlertSar: Double) {
    Card(colors = CardDefaults.cardColors(containerColor = IconBg), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(Modifier.fillMaxWidth().animateContentSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("الميزانية حتى الآن", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = DarkGreen)
            Text("إجمالي التمويل: ${money(budget.totalFundingSar)} SAR", fontWeight = FontWeight.SemiBold, color = DarkGreen)
            Text("المصروف حتى الآن: ${money(budget.spentToDateSar)} SAR", color = MaterialTheme.colorScheme.error)
            Text("المتبقي: ${money(budget.remainingSar)} SAR", fontWeight = FontWeight.Bold, color = Green)
            if (budget.remainingSar < budgetAlertSar) Text("تنبيه: المتبقي أقل من حد التنبيه ${money(budgetAlertSar)} SAR", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(
                progress = { budget.progress },
                modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),
                color = ProgressGreen,
                trackColor = Color.White
            )
            Text("تم صرف ${String.format(Locale.US, "%.1f", budget.spentPercent)}% من التمويل المسجل والحوالات المستلمة", fontSize = 12.sp, color = DarkGreen)
        }
    }
}

@Composable
private fun BalanceCard(currency: String, amount: String, name: String, modifier: Modifier, filled: Boolean) {
    val bg = if (filled) LightGreen else MaterialTheme.colorScheme.surface
    val fg = DarkGreen
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = bg), border = if (!filled) androidx.compose.foundation.BorderStroke(1.5.dp, Green) else null, elevation = CardDefaults.cardElevation(3.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("الرصيد ($currency)", fontSize = 13.sp, color = fg)
            Text(amount, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = fg, maxLines = 1)
            Text(name, fontSize = 12.sp, color = fg)
        }
    }
}

@Composable
private fun ExpenseCard(item: ExpenseRow) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(2.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(IconBg), contentAlignment = Alignment.Center) { Icon(Icons.Default.Inventory2, null, tint = Green) }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(item.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${item.whenText} • ${item.category}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("− ${money(item.amount)} ${item.currency}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
private fun StageBar(name: String, progress: Int, status: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(IconBg), contentAlignment = Alignment.Center) { Icon(Icons.Default.Foundation, null, tint = Green) }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Row { Text(name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("$progress% $status", fontSize = 12.sp, color = if (progress == 100) Green else MaterialTheme.colorScheme.onSurfaceVariant) }
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(8.dp).clip(CircleShape), color = ProgressGreen, trackColor = Color(0xFFE0E0E0))
            }
        }
    }
}

@Composable
private fun ProjectsScreen(foundationProgress: Int, stageProgress: Int, onFoundationProgress: (Int) -> Unit, onProgress: (Int) -> Unit, onGps: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("المشاريع ومراحل البناء", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = DarkGreen)
        StageBar("مرحلة الأساسات", foundationProgress, if (foundationProgress == 100) "مكتمل" else if (foundationProgress == 0) "لم تبدأ" else "قيد التنفيذ")
        Button(onClick = { onFoundationProgress((foundationProgress + 10).coerceAtMost(100)) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("تحديث تقدم الأساسات") }
        StageBar("مرحلة التشطيب", stageProgress, if (stageProgress == 0) "لم تبدأ" else if (stageProgress <= 20) "قيد الانتظار" else "قيد التنفيذ")
        Button(onClick = { onProgress((stageProgress + 10).coerceAtMost(100)) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("تحديث تقدم التشطيب") }
        OutlinedButton(onClick = onGps) { Icon(Icons.Default.LocationOn, null); Spacer(Modifier.width(8.dp)); Text("تسجيل موقع GPS") }
        Text("صور المراحل ومعلومات الموقع تحفظ مع سجل المرحلة عند إعداد Firebase.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ReportsScreen(
    currentUser: String,
    isAdmin: Boolean,
    rows: List<ExpenseRow>,
    transfers: List<Hawala>,
    workers: List<WorkerDaily>,
    householdSar: Double,
    balances: CurrencyBalances,
    budget: BudgetSummary,
    monthly: MonthlyFinancialSummary,
    exchangeRate: Double,
    familyLimitSar: Double,
    canMarkReceived: Boolean,
    onPdf: () -> Unit,
    onCalculator: () -> Unit,
    onToggleReceived: (String) -> Unit,
    onToggleWorkerPaid: (Int) -> Unit
) {
    val totalSar = rows.sumOf { LedgerTotals.sarEquivalent(it, exchangeRate) }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Text("الحساب التفصيلي", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = DarkGreen) }
        item { InfoCard("الرصيد المتاح SAR", money(balances.sar)) }
        item { InfoCard("الرصيد المتاح YER", money(balances.yer)) }
        item { InfoCard("إجمالي الرصيد المكافئ", "${money(balances.totalInSar)} SAR") }
        item { InfoCard("إجمالي التمويل", "${money(budget.totalFundingSar)} SAR") }
        item { InfoCard("المصروف حتى الآن", "${money(budget.spentToDateSar)} SAR") }
        item { InfoCard("المتبقي من الميزانية", "${money(budget.remainingSar)} SAR • ${String.format(Locale.US, "%.1f", budget.spentPercent)}% مصروف") }
        item { InfoCard("مصروفات كل السجلات", "${money(totalSar)} SAR") }
        item { InfoCard("الحوالات المرسلة هذا الشهر", "${monthly.sentCount} • ${money(monthly.sentSarEquivalent)} SAR") }
        item { InfoCard("الحوالات المقبوضة هذا الشهر", "${monthly.receivedCount} • ${money(monthly.receivedSarEquivalent)} SAR مكافئ") }
        item { InfoCard("مصروفات ومشتريات الشهر", "${money(monthly.expensesSarEquivalent)} SAR") }
        item { InfoCard("صافي الشهر (وارد − مدفوع)", "${money(monthly.netSarEquivalent)} SAR") }
        item { InfoCard("مشتريات • أجور • أسرة", "${money(monthly.purchasesSarEquivalent)} • ${money(monthly.wagesSarEquivalent)} • ${money(monthly.familySarEquivalent)} SAR") }
        item { InfoCard("حوالات بانتظار الاستلام", "${monthly.pendingCount}") }
        item { InfoCard("مصاريف الأسرة هذا الشهر", "${money(householdSar)} / ${money(familyLimitSar)} SAR") }
        item { InfoCard("الحوالات المسجلة", "${transfers.count { it.received }} مستلمة • ${transfers.count { !it.received }} معلقة") }
        item { InfoCard("سجلات الأجور", "${workers.size}") }
        item {
            Button(onClick = onPdf, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("PDF تفصيلي وإرسال عبر WhatsApp")
            }
        }
        item { OutlinedButton(onClick = onCalculator, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Calculate, null); Spacer(Modifier.width(8.dp)); Text("الحاسبة والتحويل") } }
        item { Text("الحوالات", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        if (transfers.isEmpty()) item { Text("لا توجد حوالات مسجلة بعد", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(transfers, key = { it.id }) { transfer ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("رقم ${transfer.number} • ${transfer.from} إلى ${transfer.recipient}", fontWeight = FontWeight.Bold)
                    Text("${money(transfer.amountSAR)} SAR = ${money(transfer.amountYER)} YER", color = DarkGreen)
                    Text(if (transfer.received) "الحالة: تم الاستلام" else "الحالة: بانتظار الاستلام", color = if (transfer.received) Green else MaterialTheme.colorScheme.error, fontSize = 13.sp)
                    if ((canMarkReceived || isAdmin) && !transfer.received) TextButton(onClick = { onToggleReceived(transfer.id) }) { Text("تأكيد الاستلام بعد المطابقة") }
                }
            }
        }
        item { Text("الأجور والمهن", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        if (workers.isEmpty()) item { Text("لا توجد أجور مسجلة بعد", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(workers) { index, w ->
            Column {
                InfoCard("${w.name} • ${w.job} • ${w.days} يوم", "${money(w.dailyWageSAR)} SAR / يوم")
                val totalSar = w.dailyWageSAR * w.days
                val outstandingSar = (totalSar - w.paidAmountSAR).coerceAtLeast(0.0)
                InfoCard("الأجر الإجمالي / المدفوع", "${money(totalSar)} / ${money(w.paidAmountSAR)} SAR")
                InfoCard("المتبقي", "${money(outstandingSar)} SAR")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (outstandingSar <= 0.005) "الأجر مدفوع بالكامل" else if (w.paidAmountSAR > 0.0) "مدفوع جزئياً" else "الأجر غير مدفوع", color = if (outstandingSar <= 0.005) Green else MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
                    if (outstandingSar > 0.005 && (isAdmin || w.createdBy == currentUser)) TextButton(onClick = { onToggleWorkerPaid(index) }) { Text("تأكيد سداد المتبقي") }
                }
            }
        }
    }
}

@Composable
private fun AccountScreen(user: String, role: String, settings: AppSettings, dark: Boolean, onDark: (Boolean) -> Unit, onAdminPanel: () -> Unit, onTool: (String) -> Unit, onLogout: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("الحساب والإعدادات", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = DarkGreen) }
        item { InfoCard("المستخدم الحالي", "$user${if (role == "ADMIN") " • ADMIN" else " • USER"}") }
        if (role == "ADMIN") item { Button(onClick = onAdminPanel, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("⚙️ لوحة تحكم المسؤول") } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text("الوضع الليلي", Modifier.weight(1f)); Switch(dark, onDark) } }
            listOf("تحديث", "نسخة احتياطية", "استعادة", "مشاركة واتساب", "PDF", "قائمة النواقص", "مقارنة الأسعار", "مصروفات", "إعداد البصمة").forEach { action ->
            item { OutlinedButton(onClick = { onTool(action) }, modifier = Modifier.fillMaxWidth()) { Text(action) } }
        }
        item { Text("سعر الصرف: 1 SAR = ${money(settings.exchangeRate)} YER • تنبيه: ${money(settings.budgetAlertSar)} SAR • حد الأسرة: ${money(settings.familyLimitSar)} SAR", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
        item { OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("تسجيل خروج محلي") } }
    }
}

@Composable
private fun AdminSettingsDialog(settings: AppSettings, onDismiss: () -> Unit, onSave: (AppSettings) -> Unit) {
    var exchange by remember(settings) { mutableStateOf(settings.exchangeRate.toString()) }
    var budgetAlert by remember(settings) { mutableStateOf(settings.budgetAlertSar.toString()) }
    var familyLimit by remember(settings) { mutableStateOf(settings.familyLimitSar.toString()) }
    var newType by remember { mutableStateOf("") }
    var validationMessage by remember { mutableStateOf("") }
    val types = remember(settings) { mutableStateListOf<String>().apply { addAll(settings.expenseTypes) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("لوحة تحكم المسؤول") },
        text = {
            Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المستخدمون والأدوار", fontWeight = FontWeight.Bold, color = DarkGreen)
                Text("مروان — ADMIN\nمحمد — USER\nمازن — USER", fontSize = 13.sp)
                Text("لا نعرض كلمات المرور داخل التطبيق؛ ملف APK يمكن فحصه. غيّرها عبر Firebase Secret Manager عند الحاجة.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                OutlinedTextField(exchange, { exchange = it }, label = { Text("سعر الصرف: YER لكل 1 SAR") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(budgetAlert, { budgetAlert = it }, label = { Text("حد تنبيه الميزانية (SAR)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(familyLimit, { familyLimit = it }, label = { Text("حد مصاريف الأسرة الشهري (SAR)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                Text("أنواع المصروفات", fontWeight = FontWeight.Bold, color = DarkGreen)
                types.forEach { type ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(type, Modifier.weight(1f))
                        TextButton(onClick = { if (types.size > 1) types.remove(type) }) { Text("حذف النوع") }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newType, { newType = it }, label = { Text("نوع مصروف جديد") }, modifier = Modifier.weight(1f), singleLine = true)
                    TextButton(onClick = {
                        val value = newType.trim()
                        if (value.isNotBlank() && value !in types) types.add(value)
                        newType = ""
                    }) { Text("إضافة") }
                }
                if (settings.lastUpdateTime > 0L) Text("آخر تحديث بواسطة ${settings.lastUpdateBy} • ${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar")).format(Date(settings.lastUpdateTime))}", fontSize = 11.sp)
                if (validationMessage.isNotBlank()) Text(validationMessage, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val rate = exchange.toDoubleOrNull()
                val budget = budgetAlert.toDoubleOrNull()
                val family = familyLimit.toDoubleOrNull()
                if (rate == null || rate <= 0.0 || budget == null || budget < 0.0 || family == null || family < 0.0 || types.isEmpty()) {
                    validationMessage = "أدخل سعراً موجباً وحدوداً غير سالبة ونوع مصروف واحداً على الأقل."
                } else onSave(AppSettings(rate, budget, family, types.toList(), settings.lastUpdateBy, settings.lastUpdateTime))
            }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("حفظ وتعميم التحديث") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun InfoCard(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = IconBg), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), color = DarkGreen)
            Text(value, fontWeight = FontWeight.Bold, color = Green)
        }
    }
}

@Composable
private fun RecordDialog(kind: String, user: String, exchangeRate: Double, expenseTypes: List<String>, onDismiss: () -> Unit, onSave: (String, String, String, String, String) -> Unit) {
    var first by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var paidAmount by remember { mutableStateOf("") }
    var third by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("SAR") }
    var typesExpanded by remember { mutableStateOf(false) }
    val isTransfer = kind == "إرسال حوالة" || kind == "استلام حوالة"
    val isWorker = kind == "أجرة/خدمة"
    val availableTypes = expenseTypes.filterNot { it == "مصاريف أهل" || it == "أجور" }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة $kind") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (kind == "شراء مواد") {
                OutlinedTextField(first, { first = it }, label = { Text("نوع المادة أو المصروف") }, singleLine = true,
                    trailingIcon = { IconButton(onClick = { typesExpanded = true }) { Icon(Icons.Default.ArrowDropDown, "أنواع المصروف") } })
                DropdownMenu(expanded = typesExpanded, onDismissRequest = { typesExpanded = false }) {
                    availableTypes.forEach { type -> DropdownMenuItem(text = { Text(type) }, onClick = { first = type; typesExpanded = false }) }
                }
            } else OutlinedTextField(first, { first = it }, label = { Text(if (isTransfer) "رقم الحوالة" else if (isWorker) "اسم العامل/المقاول/المهني" else "نوع المادة أو المصروف") }, singleLine = true)
            OutlinedTextField(amount, { amount = it }, label = { Text("إجمالي المبلغ ($currency)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            if (!isTransfer && kind != "مصاريف أهل") {
                OutlinedTextField(paidAmount, { paidAmount = it }, label = { Text("المدفوع الآن (اختياري)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                Text("اتركه فارغاً إذا كان المبلغ كاملاً مدفوعاً؛ ويمكن إدخال جزء منه لحساب المتبقي.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SAR", "YER").forEach { unit ->
                    FilterChip(selected = currency == unit, onClick = { currency = unit }, label = { Text(unit) })
                }
            }
            if (isTransfer && kind == "استلام حوالة") {
                OutlinedTextField(third, { third = it }, label = { Text("اسم المرسل: مروان أو محمد (إلزامي)") }, singleLine = true)
                Text("لن يتم تأكيد الاستلام دون مطابقة اسم المرسل والرقم والمبلغ.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else if (isWorker) OutlinedTextField(third, { third = it }, label = { Text("المهنة: عامل/مقاول/سباك/مهندس/كهربائي/نجار/حداد") }, singleLine = true)
            else if (kind == "إرسال حوالة") OutlinedTextField(third, { third = it }, label = { Text("مكتب الحوالة (اختياري)") }, singleLine = true)
            else if (kind == "شراء مواد") OutlinedTextField(third, { third = it }, label = { Text("اسم المورد أو المتجر") }, singleLine = true)
            else OutlinedTextField(third, { third = it }, label = { Text("اسم التاجر أو التصنيف") }, singleLine = true)
            if (isTransfer && kind == "إرسال حوالة") Text("المرسل: $user • المستلم: مازن", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("سعر الصرف الحالي: 1 SAR = ${money(exchangeRate)} YER", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } },
        confirmButton = { TextButton(onClick = { onSave(first.ifBlank { kind }, amount, third, currency, paidAmount) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun PdfAccountSelectionDialog(onDismiss: () -> Unit, onShare: (List<String>) -> Unit) {
    val selected = remember { mutableStateListOf<String>().apply { addAll(Constants.TEAM_MEMBERS) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إعداد تقرير PDF") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("اختر حساباً واحداً أو عدة حسابات لإدراج سجلاتها في التقرير.", fontSize = 13.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = { selected.clear(); selected.addAll(Constants.TEAM_MEMBERS) }) { Text("تحديد الكل") }
                    TextButton(onClick = { selected.clear() }) { Text("إلغاء التحديد") }
                }
                Constants.TEAM_MEMBERS.forEach { name ->
                    val checked = name in selected
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            if (checked) selected.remove(name) else selected.add(name)
                        },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = checked, onCheckedChange = { value ->
                            if (value && name !in selected) selected.add(name)
                            if (!value) selected.remove(name)
                        })
                        Text(name, fontWeight = FontWeight.Medium)
                    }
                }
                Text("يتضمن التقرير الحوالات والمشتريات والمبالغ المدفوعة والمتبقية وأسماء التجار والأجور.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (selected.isEmpty()) Text("اختر حساباً واحداً على الأقل.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = { onShare(selected.toList()) }, enabled = selected.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text("إنشاء ومشاركة PDF")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun SimpleDialog(title: String, body: String, close: () -> Unit) {
    AlertDialog(onDismissRequest = close, title = { Text(title) }, text = { Text(body) }, confirmButton = { TextButton(onClick = close) { Text("حسناً") } })
}

@Composable
private fun CalculatorDialog(exchangeRate: Double, close: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text("حاسبة وتحويل العملات") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, label = { Text("المبلغ") })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { result = input.toDoubleOrNull()?.let { "${money(Constants.sarToYer(it, exchangeRate))} YER" } ?: "أدخل رقماً" }) { Text("SAR → YER") }
                Button(onClick = { result = input.toDoubleOrNull()?.let { "${money(Constants.yerToSar(it, exchangeRate))} SAR" } ?: "أدخل رقماً" }) { Text("YER → SAR") }
            }
            Text(result, fontWeight = FontWeight.Bold)
            Text("سعر حالي: 1 SAR = ${money(exchangeRate)} YER", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }, confirmButton = { TextButton(onClick = close) { Text("إغلاق") } })
}

@Composable
private fun TextListDialog(title: String, values: List<String>, onAdd: (String) -> Unit, close: () -> Unit) {
    var item by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text(title) }, text = {
        Column {
            OutlinedTextField(item, { item = it }, label = { Text(if (title == "قائمة النواقص") "الصنف الناقص" else "الصنف: السعر والمورد") })
            TextButton(onClick = { if (item.isNotBlank()) { onAdd(item); item = "" } }) { Text("إضافة") }
            values.forEach { Text("• $it", modifier = Modifier.padding(vertical = 3.dp)) }
        }
    }, confirmButton = { TextButton(onClick = close) { Text("إغلاق") } })
}

@Composable
private fun BackupDialog(close: () -> Unit) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let { runCatching { context.contentResolver.openOutputStream(it)?.use { stream -> stream.write("{\"exchangeRate\":140,\"app\":\"${Constants.PACKAGE}\"}".toByteArray()) } } }
        close()
    }
    AlertDialog(onDismissRequest = close, title = { Text("نسخة احتياطية") }, text = { Text("حفظ ملف إعداد/نسخة محلية بصيغة JSON. يلزم توسيع التصدير ليشمل السجلات الكاملة قبل الاعتماد عليه كنسخة شاملة.") }, confirmButton = { TextButton(onClick = { launcher.launch("hasabi-backup.json") }) { Text("حفظ ملف") } }, dismissButton = { TextButton(onClick = close) { Text("إلغاء") } })
}

@Composable
private fun RestoreDialog(close: () -> Unit) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }
        close()
    }
    AlertDialog(onDismissRequest = close, title = { Text("استعادة") }, text = { Text("اختر ملف JSON. الاستعادة الكاملة للسجلات غير مفعلة في هذه النسخة الأولية.") }, confirmButton = { TextButton(onClick = { launcher.launch(arrayOf("application/json")) }) { Text("اختيار ملف") } }, dismissButton = { TextButton(onClick = close) { Text("إلغاء") } })
}

private fun defaultExpenses(): List<ExpenseRow> = emptyList()

private fun money(value: Double): String = NumberFormat.getNumberInstance(Locale.US).format(value)
private fun remainingSar(rows: List<ExpenseRow>, transfers: List<Hawala>, exchangeRate: Double) = LedgerTotals.balances(rows, transfers, exchangeRate).totalInSar

private fun syncExpense(context: android.content.Context, expense: Expense) {
    runCatching {
        if (FirebaseApp.getApps(context).isNotEmpty()) {
            FirebaseFirestore.getInstance().collection("expenses").document(expense.id).set(
                mapOf("type" to expense.type, "trader" to expense.trader, "amountSAR" to expense.amountSAR,
                    "amountYER" to expense.amountYER, "createdBy" to expense.createdBy, "date" to expense.date)
            )
        }
    }
}


private fun createPdf(context: android.content.Context, rows: List<ExpenseRow>) {
    val document = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = document.startPage(pageInfo)
    val paint = Paint().apply { textSize = 18f; color = android.graphics.Color.rgb(27, 94, 32) }
    page.canvas.drawText("Daftar Hesabat - Expense Report", 40f, 48f, paint)
    paint.textSize = 13f
    var y = 90f
    rows.forEach { row -> page.canvas.drawText("${row.name}: ${row.amount} ${row.currency} | ${row.whenText}", 40f, y, paint); y += 28f }
    page.canvas.drawText("Fixed exchange rate: 1 SAR = 140 YER", 40f, y + 20f, paint)
    document.finishPage(page)
    runCatching {
        val file = java.io.File(context.cacheDir, "hasabi-report.pdf")
        file.outputStream().use(document::writeTo)
        val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        context.startActivity(Intent.createChooser(intent, "مشاركة التقرير PDF"))
    }
    document.close()
}

private fun shareWhatsApp(context: android.content.Context, rows: List<ExpenseRow>) {
    val text = buildString {
        append("دفتر حسابات — ملخص المصروفات\n")
        rows.forEach { append("${it.name}: ${money(it.amount)} ${it.currency} • ${it.whenText}\n") }
        append("سعر الصرف الثابت: 1 SAR = 140 YER")
    }
    val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text); setPackage("com.whatsapp") }
    runCatching { context.startActivity(intent) }.onFailure {
        val fallback = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
        runCatching { context.startActivity(Intent.createChooser(fallback, "مشاركة الملخص")) }
    }
}

private const val FRESH_START_KEY = "freshStartLedgerV2"

private fun clearLocalHistoryOnce(prefs: android.content.SharedPreferences) {
    if (prefs.getBoolean(FRESH_START_KEY, false)) return
    val keepKeys = setOf("user", "current_user", "current_role", "isLoggedIn", "dark", "syncDeviceId", "biometric_enabled")
    prefs.edit().apply {
        prefs.all.keys.filterNot { it in keepKeys }.forEach { remove(it) }
        putBoolean(FRESH_START_KEY, true)
    }.commit()
}

private fun loadExpenses(raw: String?): List<ExpenseRow> {
    if (raw.isNullOrBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        (0 until array.length()).map { i -> array.getJSONObject(i).let { ExpenseRow(it.optString("name"), it.optDouble("amount"), it.optString("currency"), it.optString("when"), it.optString("category"), it.optString("trader"), it.optString("createdBy", "مازن"), it.optLong("date", System.currentTimeMillis()), it.optString("id", UUID.randomUUID().toString()), it.optDouble("paidAmount", it.optDouble("amount")), it.optDouble("exchangeRateAtEntry", Constants.EXCHANGE_RATE)) } }
    }.getOrElse { emptyList() }
}

private fun saveExpenses(prefs: android.content.SharedPreferences, rows: List<ExpenseRow>) {
    val array = JSONArray()
    rows.forEach { row -> array.put(JSONObject().put("name", row.name).put("amount", row.amount).put("currency", row.currency).put("when", row.whenText).put("category", row.category).put("trader", row.trader).put("createdBy", row.createdBy).put("date", row.date).put("id", row.id).put("paidAmount", row.paidAmount).put("exchangeRateAtEntry", row.exchangeRateAtEntry)) }
    prefs.edit().putString("expenses", array.toString()).apply()
}
