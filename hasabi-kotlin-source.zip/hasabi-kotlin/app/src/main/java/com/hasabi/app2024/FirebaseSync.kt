package com.hasabi.app2024

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Timestamp
import com.google.firebase.functions.FirebaseFunctions
import java.util.UUID

private const val FIREBASE_REGION = "asia-south1"

private fun firebaseAppOrNull(context: Context): FirebaseApp? =
    FirebaseApp.getApps(context).firstOrNull()

private fun firestoreOrNull(context: Context): FirebaseFirestore? = runCatching {
    firebaseAppOrNull(context)?.let { app ->
        if (FirebaseAuth.getInstance(app).currentUser == null) null else FirebaseFirestore.getInstance(app)
    }
}.getOrNull()

fun deviceInstallationId(context: Context): String {
    val prefs = context.getSharedPreferences("hasabi-local", Context.MODE_PRIVATE)
    val existing = prefs.getString("syncDeviceId", null)
    if (!existing.isNullOrBlank()) return existing
    val created = UUID.randomUUID().toString()
    prefs.edit().putString("syncDeviceId", created).apply()
    return created
}

private fun expectedTeamUid(userName: String): String? = when (userName) {
    "مروان" -> "hasabi-marwan"
    "محمد" -> "hasabi-mohammed"
    "مازن" -> "hasabi-mazen"
    else -> null
}

/** Exchanges a name+password pair for a matching Firebase custom token; passwords are never persisted in the app. */
fun authenticateTeamPassword(context: Context, password: String, userName: String, onResult: (Boolean, String?, String?) -> Unit) {
    val app = firebaseAppOrNull(context)
    val expectedUid = expectedTeamUid(userName)
    if (app == null || expectedUid == null) {
        onResult(false, null, "تعذر التحقق من الحساب")
        return
    }
    val auth = FirebaseAuth.getInstance(app)
    auth.signOut()
    runCatching {
        FirebaseFunctions.getInstance(app, FIREBASE_REGION)
            .getHttpsCallable("exchangePasswordForCustomToken")
            .call(mapOf("password" to password, "userName" to userName, "deviceId" to deviceInstallationId(context)))
            .addOnSuccessListener { result ->
                val token = (result.data as? Map<*, *>)?.get("token") as? String
                if (token.isNullOrBlank()) {
                    onResult(false, null, "لم يرجع خادم Firebase رمز دخول صالحاً")
                } else {
                    auth.signInWithCustomToken(token)
                        .addOnSuccessListener { authResult ->
                            if (authResult.user?.uid == expectedUid) {
                                authResult.user?.getIdToken(false)
                                    ?.addOnSuccessListener { tokenResult ->
                                        val role = tokenResult.claims["role"] as? String
                                        val tokenUser = tokenResult.claims["userName"] as? String
                                        val expectedRole = if (userName == "مروان") "ADMIN" else "USER"
                                        if (role == expectedRole && tokenUser == userName) onResult(true, role, null)
                                        else { auth.signOut(); onResult(false, null, "الدور الموثوق لا يطابق الحساب") }
                                    }
                                    ?.addOnFailureListener { auth.signOut(); onResult(false, null, it.localizedMessage) }
                                    ?: run { auth.signOut(); onResult(false, null, "تعذر قراءة صلاحية الحساب") }
                            } else {
                                auth.signOut()
                                onResult(false, null, "الاسم لا يطابق الحساب")
                            }
                        }
                        .addOnFailureListener { onResult(false, null, it.localizedMessage) }
                }
            }
            .addOnFailureListener { onResult(false, null, it.localizedMessage) }
    }.onFailure { onResult(false, null, it.localizedMessage) }
}

fun listenAppSettings(context: Context, onData: (AppSettings) -> Unit, onError: (String) -> Unit): ListenerRegistration? {
    val db = firestoreOrNull(context) ?: return null
    return db.collection("app_settings").document("config").addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
        if (error != null) { onError("تعذر مزامنة إعدادات التطبيق"); return@addSnapshotListener }
        val doc = snapshot ?: return@addSnapshotListener
        if (!doc.exists()) { onData(AppSettings()); return@addSnapshotListener }
        val types = (doc.get("expense_types") as? List<*>)?.mapNotNull { it as? String }?.filter { it.isNotBlank() }?.distinct()
            ?.takeIf { it.isNotEmpty() } ?: Constants.DEFAULT_EXPENSE_TYPES
        val updatedAt = (doc.get("last_update_time") as? Timestamp)?.toDate()?.time ?: 0L
        onData(AppSettings(
            exchangeRate = (doc.getDouble("exchange_rate") ?: Constants.EXCHANGE_RATE).takeIf { it > 0.0 } ?: Constants.EXCHANGE_RATE,
            budgetAlertSar = (doc.getDouble("budget_alert") ?: Constants.DEFAULT_BUDGET_ALERT_SAR).coerceAtLeast(0.0),
            familyLimitSar = (doc.getDouble("family_limit") ?: Constants.FAMILY_MONTHLY_LIMIT_SAR).coerceAtLeast(0.0),
            expenseTypes = types,
            lastUpdateBy = doc.getString("last_update_by") ?: "",
            lastUpdateTime = updatedAt
        ))
    }
}

fun syncAppSettings(context: Context, settings: AppSettings, updatedBy: String, onResult: (Boolean, String?) -> Unit) {
    val db = firestoreOrNull(context)
    if (db == null) { onResult(false, "يلزم جلسة Firebase نشطة لحفظ الإعدادات"); return }
    val rate = settings.exchangeRate
    if (!rate.isFinite() || rate <= 0.0 || !settings.budgetAlertSar.isFinite() || settings.budgetAlertSar < 0.0 ||
        !settings.familyLimitSar.isFinite() || settings.familyLimitSar < 0.0 || settings.expenseTypes.isEmpty()) {
        onResult(false, "تحقق من القيم وأنواع المصروفات"); return
    }
    db.collection("app_settings").document("config").set(mapOf(
        "exchange_rate" to rate,
        "budget_alert" to settings.budgetAlertSar,
        "family_limit" to settings.familyLimitSar,
        "expense_types" to settings.expenseTypes.distinct().filter { it.isNotBlank() },
        "last_update_by" to updatedBy,
        "last_update_time" to FieldValue.serverTimestamp()
    )).addOnSuccessListener { onResult(true, null) }
        .addOnFailureListener { onResult(false, it.localizedMessage ?: "تعذر حفظ الإعدادات") }
}

fun loadVerifiedTeamRole(context: Context, userName: String, onResult: (String?) -> Unit) {
    val user = runCatching { firebaseAppOrNull(context)?.let { FirebaseAuth.getInstance(it).currentUser } }.getOrNull()
    user?.getIdToken(false)?.addOnSuccessListener { result ->
        val expected = if (userName == "مروان") "ADMIN" else "USER"
        val actual = result.claims["role"] as? String
        onResult(actual.takeIf { it == expected && result.claims["userName"] == userName })
    }?.addOnFailureListener { onResult(null) } ?: onResult(null)
}

fun signOutFirebaseTeam(context: Context) {
    runCatching { unsubscribeFromLedgerNotifications(context) }
    runCatching { firebaseAppOrNull(context)?.let { FirebaseAuth.getInstance(it).signOut() } }
}

fun hasFirebaseTeamSession(context: Context, userName: String): Boolean = runCatching {
    val expectedUid = expectedTeamUid(userName) ?: return@runCatching false
    firebaseAppOrNull(context)?.let { FirebaseAuth.getInstance(it).currentUser?.uid == expectedUid } == true
}.getOrDefault(false)

fun listenTransfers(
    context: Context,
    onData: (List<Hawala>) -> Unit,
    onStatus: (String) -> Unit
): ListenerRegistration? {
    val db = firestoreOrNull(context) ?: return null
    return db.collection("transfers").addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
        if (error != null) {
            onStatus("تعذر مزامنة الحوالات")
            return@addSnapshotListener
        }
        if (snapshot == null) return@addSnapshotListener
        val rows = snapshot.documents.mapNotNull { d ->
            runCatching {
                val amountSar = d.getDouble("amountSAR") ?: 0.0
                val amountYer = d.getDouble("amountYER") ?: Constants.sarToYer(amountSar)
                val received = d.getBoolean("received") ?: false
                val receivedCurrency = d.getString("receivedCurrency") ?: "YER"
                val date = d.getLong("date") ?: System.currentTimeMillis()
                Hawala(
                    id = d.id,
                    number = d.getString("number") ?: "",
                    amountSAR = amountSar,
                    amountYER = amountYer,
                    from = d.getString("from") ?: "",
                    recipient = d.getString("recipient") ?: "مازن",
                    date = date,
                    createdBy = d.getString("createdBy") ?: "",
                    received = received,
                    receivedCurrency = receivedCurrency,
                    receivedAmount = d.getDouble("receivedAmount") ?: if (receivedCurrency == "YER") amountYer else amountSar,
                    receivedAt = d.getLong("receivedAt") ?: if (received) date else 0L,
                    receiptImage = d.getString("receiptImage") ?: "",
                    exchangeRateAtEntry = d.getDouble("exchangeRateAtEntry") ?: Constants.EXCHANGE_RATE,
                    receivedExchangeRate = d.getDouble("receivedExchangeRate") ?: Constants.EXCHANGE_RATE
                )
            }.getOrNull()
        }.sortedBy { it.date }
        onData(rows)
        onStatus(if (snapshot.metadata.isFromCache) "غير متصل — يعرض آخر نسخة محفوظة" else "متصل — الحوالات محدثة")
    }
}

fun listenExpenseRows(
    context: Context,
    onData: (List<ExpenseRow>) -> Unit,
    onStatus: (String) -> Unit
): ListenerRegistration? {
    val db = firestoreOrNull(context) ?: return null
    return db.collection("expenses").addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
        if (error != null) {
            onStatus("تعذر مزامنة المصروفات")
            return@addSnapshotListener
        }
        if (snapshot == null) return@addSnapshotListener
        val rows = snapshot.documents.mapNotNull { d ->
            runCatching {
                val amountSar = d.getDouble("amountSAR") ?: 0.0
                val amountYer = d.getDouble("amountYER") ?: Constants.sarToYer(amountSar)
                val currency = d.getString("currency") ?: "SAR"
                val amount = d.getDouble("amount") ?: if (currency == "YER") amountYer else amountSar
                ExpenseRow(
                    id = d.id,
                    name = d.getString("name") ?: d.getString("type") ?: "مصروف",
                    amount = amount,
                    currency = currency,
                    whenText = d.getString("whenText") ?: "مسجل",
                    category = d.getString("category") ?: "مواد بناء",
                    trader = d.getString("trader") ?: "",
                    createdBy = d.getString("createdBy") ?: "مازن",
                    date = d.getLong("date") ?: System.currentTimeMillis(),
                    paidAmount = d.getDouble("paidAmount") ?: amount,
                    exchangeRateAtEntry = d.getDouble("exchangeRateAtEntry") ?: Constants.EXCHANGE_RATE
                )
            }.getOrNull()
        }.sortedByDescending { it.date }
        onData(rows)
        onStatus(if (snapshot.metadata.isFromCache) "غير متصل — يعرض آخر نسخة محفوظة" else "متصل — المصروفات محدثة")
    }
}

fun listenWorkerRecords(
    context: Context,
    onData: (List<WorkerDaily>) -> Unit,
    onStatus: (String) -> Unit
): ListenerRegistration? {
    val db = firestoreOrNull(context) ?: return null
    return db.collection("worker_daily").addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
        if (error != null) {
            onStatus("تعذر مزامنة أجور العمال")
            return@addSnapshotListener
        }
        if (snapshot == null) return@addSnapshotListener
        val rows = snapshot.documents.mapNotNull { d ->
            runCatching {
                val days = d.getLong("days")?.toInt() ?: 1
                val dailySar = d.getDouble("dailyWageSAR") ?: 0.0
                val dailyYer = d.getDouble("dailyWageYER") ?: Constants.sarToYer(dailySar)
                val paid = d.getBoolean("paid") ?: false
                WorkerDaily(
                    name = d.getString("name") ?: "",
                    job = d.getString("job") ?: "عامل",
                    days = days,
                    dailyWageYER = dailyYer,
                    dailyWageSAR = dailySar,
                    paid = paid,
                    date = d.getLong("date") ?: System.currentTimeMillis(),
                    createdBy = d.getString("createdBy") ?: "مازن",
                    paidAmountSAR = d.getDouble("paidAmountSAR") ?: if (paid) dailySar * days else 0.0,
                    paidAmountYER = d.getDouble("paidAmountYER") ?: if (paid) dailyYer * days else 0.0,
                    exchangeRateAtEntry = d.getDouble("exchangeRateAtEntry") ?: Constants.EXCHANGE_RATE
                )
            }.getOrNull()
        }.sortedBy { it.date }
        onData(rows)
        onStatus(if (snapshot.metadata.isFromCache) "غير متصل — أجور محفوظة محلياً" else "متصل — أجور العمال محدثة")
    }
}

fun syncExpenseRow(context: Context, row: ExpenseRow) {
    firestoreOrNull(context)?.collection("expenses")?.document(row.id)?.set(
        mapOf(
            "id" to row.id,
            "name" to row.name,
            "type" to row.name,
            "amount" to row.amount,
            "currency" to row.currency,
            "amountSAR" to if (row.currency == "YER") Constants.yerToSar(row.amount, row.exchangeRateAtEntry) else row.amount,
            "amountYER" to if (row.currency == "YER") row.amount else Constants.sarToYer(row.amount, row.exchangeRateAtEntry),
            "paidAmount" to row.paidAmount,
            "whenText" to row.whenText,
            "category" to row.category,
            "trader" to row.trader,
            "createdBy" to row.createdBy,
            "date" to row.date,
            "exchangeRateAtEntry" to row.exchangeRateAtEntry
        )
    )
}

fun syncExpenseRecord(context: Context, expense: Expense) {
    firestoreOrNull(context)?.collection("expenses")?.document(expense.id)?.set(
        mapOf(
            "id" to expense.id, "type" to expense.type, "name" to expense.type,
            "trader" to expense.trader, "amountSAR" to expense.amountSAR,
            "amountYER" to expense.amountYER, "currency" to "YER", "amount" to expense.amountYER,
            "paidAmount" to expense.amountYER,
            "category" to expense.type, "whenText" to "مسجل", "date" to expense.date,
            "createdBy" to expense.createdBy, "relatedTransferId" to expense.relatedTransferId,
            "exchangeRateAtEntry" to expense.exchangeRateAtEntry
        )
    )
}

fun syncTransferRecord(context: Context, transfer: Hawala) {
    val ref = firestoreOrNull(context)?.collection("transfers")?.document(transfer.id) ?: return
    if (transfer.received) {
        ref.update(
            mapOf(
                "received" to true,
                "receivedCurrency" to transfer.receivedCurrency,
                "receivedAmount" to transfer.receivedAmount,
                "receivedAt" to transfer.receivedAt,
                "receivedExchangeRate" to transfer.receivedExchangeRate
            )
        )
    } else {
        ref.set(mapOf(
            "id" to transfer.id, "number" to transfer.number, "amountSAR" to transfer.amountSAR,
            "amountYER" to transfer.amountYER, "from" to transfer.from, "recipient" to transfer.recipient,
            "date" to transfer.date, "createdBy" to transfer.createdBy, "received" to transfer.received,
            "receivedCurrency" to transfer.receivedCurrency, "receivedAmount" to transfer.receivedAmount,
            "receivedAt" to transfer.receivedAt, "receiptImage" to transfer.receiptImage,
            "exchangeRateAtEntry" to transfer.exchangeRateAtEntry, "receivedExchangeRate" to transfer.receivedExchangeRate
        ))
    }
}

fun syncWorkerRecord(context: Context, worker: WorkerDaily) {
    val documentId = "${worker.date}-${worker.name}-${worker.job}".hashCode().toString()
    firestoreOrNull(context)?.collection("worker_daily")?.document(documentId)?.set(
        mapOf(
            "name" to worker.name, "job" to worker.job, "days" to worker.days,
            "dailyWageSAR" to worker.dailyWageSAR, "dailyWageYER" to worker.dailyWageYER,
            "paid" to worker.paid, "paidAmountSAR" to worker.paidAmountSAR,
            "paidAmountYER" to worker.paidAmountYER, "date" to worker.date, "createdBy" to worker.createdBy,
            "exchangeRateAtEntry" to worker.exchangeRateAtEntry
        )
    )
}
