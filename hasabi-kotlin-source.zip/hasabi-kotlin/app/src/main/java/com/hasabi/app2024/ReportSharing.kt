package com.hasabi.app2024

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun shareDetailedPdf(
    context: Context,
    selectedAccounts: List<String>,
    expenses: List<ExpenseRowForReport>,
    transfers: List<Hawala>,
    workers: List<WorkerDaily>,
    householdSar: Double,
    createdBy: String,
    exchangeRate: Double,
    familyLimitSar: Double
) {
    if (selectedAccounts.isEmpty()) return
    val document = PdfDocument()
    val writer = DesignedPdfWriter(document)
    val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar"))

    val receivedSar = transfers.filter { it.received && it.receivedCurrency == "SAR" }.sumOf { it.receivedAmount }
    val receivedYer = transfers.filter { it.received && it.receivedCurrency == "YER" }.sumOf { it.receivedAmount }
    val pendingSar = transfers.filterNot { it.received }.sumOf { it.amountSAR }
    val materialExpenses = expenses.filterNot { isWageCategory(it.category) }
    val wageExpenseRows = expenses.filter { isWageCategory(it.category) }
    val materialTotalSar = materialExpenses.sumOf { it.amountSar }
    val materialPaidSar = materialExpenses.sumOf { it.paidAmountSar }
    val wageRowsTotalSar = wageExpenseRows.sumOf { it.amountSar }
    val workerTotalSar = workers.sumOf { it.dailyWageSAR * it.days }
    val wageTotalSar = if (wageRowsTotalSar > 0.0) wageRowsTotalSar else workerTotalSar
    val wageRowsPaidSar = wageExpenseRows.sumOf { it.paidAmountSar }
    val workerPaidSar = workers.sumOf { it.paidAmountSAR.coerceIn(0.0, it.dailyWageSAR * it.days) }
    val wagePaidSar = if (wageRowsTotalSar > 0.0) wageRowsPaidSar else workerPaidSar
    val totalCostSar = materialTotalSar + wageTotalSar
    val totalPaidSar = (materialPaidSar + wagePaidSar).coerceAtMost(totalCostSar)
    val outstandingSar = (totalCostSar - totalPaidSar).coerceAtLeast(0.0)
    val fundingSar = receivedSar + transfers.filter { it.received && it.receivedCurrency == "YER" }
        .sumOf { Constants.yerToSar(it.receivedAmount, it.receivedExchangeRate) }
    val remainingBudgetSar = fundingSar - totalCostSar
    val cashSar = receivedSar - expenses.filter { it.currency == "SAR" }.sumOf { it.paidAmountSar }
    val cashYer = receivedYer - expenses.filter { it.currency == "YER" }.sumOf { it.paidAmountYer }

    writer.drawParagraph("كشف حساب تفصيلي", 22f, DarkGreenPdf, true, gapAfter = 4f)
    writer.drawParagraph("الحسابات المختارة: ${selectedAccounts.joinToString(" • ")}", 12f, GrayPdf, false, gapAfter = 2f)
    writer.drawParagraph("إعداد: ${createdBy.ifBlank { "—" }}   •   ${dateFormat.format(Date())}", 11f, GrayPdf, false, gapAfter = 4f)
    writer.drawParagraph("سعر الصرف الحالي: 1 SAR = ${formatMoney(exchangeRate)} YER", 11f, GreenPdf, true, gapAfter = 10f)

    writer.drawMetrics(
        listOf(
            "تمويل مستلم" to "${formatMoney(fundingSar)} SAR",
            "تكاليف مسجلة" to "${formatMoney(totalCostSar)} SAR",
            "مدفوع" to "${formatMoney(totalPaidSar)} SAR",
            "متبقي للموردين" to "${formatMoney(outstandingSar)} SAR"
        )
    )
    writer.drawSection("ملخص الرصيد والميزانية")
    writer.drawCard(
        "الرصيد النقدي ضمن السجلات المختارة",
        "${formatMoney(cashSar)} SAR   •   ${formatMoney(cashYer)} YER\n" +
            "الفرق بين التمويل والالتزامات المسجلة لهذه الحسابات: ${formatMoney(remainingBudgetSar)} SAR\n" +
            "حوالات بانتظار الاستلام: ${transfers.count { !it.received }} (${formatMoney(pendingSar)} SAR مكافئ)\n" +
            "عدد الحوالات: ${transfers.size}  •  المصروفات: ${expenses.size}  •  سجلات الأجور: ${workers.size}",
        GreenPdf
    )
    writer.drawCard(
        "مصاريف الأسرة للشهر الحالي",
        "المسجل: ${formatMoney(householdSar)} SAR  •  الحد الشهري: ${formatMoney(familyLimitSar)} SAR  •  المتبقي من الحد: ${formatMoney((familyLimitSar - householdSar).coerceAtLeast(0.0))} SAR",
        GreenPdf
    )

    selectedAccounts.forEach { account ->
        writer.drawSection("كشف الحساب: $account")
        val accountTransfers = transfers.filter { it.from == account || it.recipient == account || it.createdBy == account }
        val accountExpenses = expenses.filter { it.createdBy == account }
        val accountWorkers = workers.filter { it.createdBy == account }
        writer.drawCard(
            "ملخص سجلات $account",
            "حوالات مرتبطة بالحساب: ${accountTransfers.size}  •  مصروفات مسجلة منه: ${accountExpenses.size}  •  أجور مسجلة منه: ${accountWorkers.size}\n" +
                "إجمالي المصروف المسجل: ${formatMoney(accountExpenses.sumOf { it.amountSar })} SAR  •  المدفوع: ${formatMoney(accountExpenses.sumOf { it.paidAmountSar })} SAR  •  المتبقي: ${formatMoney((accountExpenses.sumOf { it.amountSar } - accountExpenses.sumOf { it.paidAmountSar }).coerceAtLeast(0.0))} SAR\n" +
                "السجلات تُعرض بحسب منشئها؛ والحوالة تظهر للحساب المُرسل أو المستلم.",
            GreenPdf
        )

        writer.drawSection("الحوالات المرتبطة بحساب $account (${accountTransfers.size})")
        if (accountTransfers.isEmpty()) writer.drawCard("لا توجد حوالات", "لا توجد حوالات مرتبطة بالحساب المختار.", GrayPdf)
        accountTransfers.sortedBy { it.date }.forEach { transfer ->
            val receivedText = if (transfer.received) "مستلمة فعلياً: ${formatMoney(transfer.receivedAmount)} ${transfer.receivedCurrency}\nتاريخ الاستلام: ${if (transfer.receivedAt > 0L) dateFormat.format(Date(transfer.receivedAt)) else "—"}" else "الحالة: بانتظار الاستلام"
            writer.drawCard(
                "حوالة رقم ${transfer.number.ifBlank { "—" }}",
                "من: ${transfer.from.ifBlank { "—" }}  •  إلى: ${transfer.recipient}\n" +
                    "المبلغ المرسل: ${formatMoney(transfer.amountSAR)} SAR = ${formatMoney(transfer.amountYER)} YER\n" +
                    "$receivedText\n" +
                    "منشئ السجل: ${transfer.createdBy.ifBlank { "—" }}  •  التاريخ: ${dateFormat.format(Date(transfer.date))}",
                GreenPdf
            )
        }

        val accountPurchaseRows = accountExpenses.filterNot { isWageCategory(it.category) }
        writer.drawSection("المشتريات والمصروفات (${accountPurchaseRows.size})")
        if (accountPurchaseRows.isEmpty()) writer.drawCard("لا توجد مشتريات", "لا توجد مشتريات أو مصروفات مسجلة لهذا الحساب.", GrayPdf)
        accountPurchaseRows.sortedBy { it.dateMillis }.forEach { expense ->
            val remainderSar = (expense.amountSar - expense.paidAmountSar).coerceAtLeast(0.0)
            val remainderYer = (expense.amountYer - expense.paidAmountYer).coerceAtLeast(0.0)
            writer.drawCard(
                "${expense.name}  •  ${expense.category}",
                "التاجر / المورد: ${expense.trader.ifBlank { "—" }}\n" +
                    "الإجمالي: ${formatMoney(expense.amountSar)} SAR = ${formatMoney(expense.amountYer)} YER\n" +
                    "المدفوع: ${formatMoney(expense.paidAmountSar)} SAR = ${formatMoney(expense.paidAmountYer)} YER\n" +
                    "المتبقي: ${formatMoney(remainderSar)} SAR = ${formatMoney(remainderYer)} YER\n" +
                    "سجلها: ${expense.createdBy.ifBlank { "—" }}  •  التاريخ: ${expense.dateText.ifBlank { "—" }}${if (expense.dateMillis > 0L) " (${dateFormat.format(Date(expense.dateMillis))})" else ""}",
                GreenPdf
            )
        }

        writer.drawSection("أجور العمال والمهنيين (${accountWorkers.size})")
        if (accountWorkers.isEmpty() && accountExpenses.none { isWageCategory(it.category) }) {
            writer.drawCard("لا توجد أجور مسجلة", "لا توجد سجلات أجور مرتبطة بهذا الحساب.", GrayPdf)
        }
        accountWorkers.sortedBy { it.date }.forEach { worker ->
            val totalSar = worker.dailyWageSAR * worker.days
            val totalYer = worker.dailyWageYER * worker.days
            val paidSar = worker.paidAmountSAR.coerceIn(0.0, totalSar)
            val paidYer = worker.paidAmountYER.coerceIn(0.0, totalYer)
            writer.drawCard(
                "${worker.name}  •  ${worker.job}",
                "الأيام: ${worker.days}  •  الأجر اليومي: ${formatMoney(worker.dailyWageSAR)} SAR = ${formatMoney(worker.dailyWageYER)} YER\n" +
                    "إجمالي الأجر: ${formatMoney(totalSar)} SAR = ${formatMoney(totalYer)} YER\n" +
                    "المدفوع: ${formatMoney(paidSar)} SAR = ${formatMoney(paidYer)} YER\n" +
                    "المتبقي: ${formatMoney((totalSar - paidSar).coerceAtLeast(0.0))} SAR = ${formatMoney((totalYer - paidYer).coerceAtLeast(0.0))} YER\n" +
                    "الحالة: ${if (paidSar >= totalSar) "مدفوع بالكامل" else if (paidSar > 0.0) "مدفوع جزئياً" else "غير مدفوع"}  •  سجلها: ${worker.createdBy}  •  ${dateFormat.format(Date(worker.date))}",
                GreenPdf
            )
        }
    }

    writer.drawSection("ملاحظات التقرير")
    writer.drawCard(
        "طريقة الاحتساب",
        "المجاميع تخص الحسابات المختارة فقط؛ اختر مروان ومحمد ومازن لعرض إجمالي سجلات الفريق. سعر الصرف الحالي ${formatMoney(exchangeRate)} YER لكل SAR؛ تحتفظ السجلات بتاريخها ومعدلها عند الإدخال. الرصيد النقدي يُنقص بالمبالغ المدفوعة فقط، بينما الفرق بين التمويل والتكاليف يحتسب كامل الالتزامات المسجلة.",
        GrayPdf
    )
    writer.finish()

    val file = File(context.cacheDir, "daftar-hesabat-report-${System.currentTimeMillis()}.pdf")
    file.outputStream().use(document::writeTo)
    document.close()

    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    fun shareIntent(packageName: String? = null) = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "كشف حساب دفتر حسابات")
        putExtra(Intent.EXTRA_TEXT, "كشف حساب دفتر حسابات للحسابات: ${selectedAccounts.joinToString(" • ")}")
        clipData = ClipData.newUri(context.contentResolver, "كشف حساب دفتر حسابات", uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        if (packageName != null) setPackage(packageName)
    }
    try {
        context.startActivity(shareIntent("com.whatsapp"))
    } catch (_: Exception) {
        try {
            context.startActivity(shareIntent("com.whatsapp.w4b"))
        } catch (_: Exception) {
            context.startActivity(Intent.createChooser(shareIntent(), "إرسال PDF عبر WhatsApp أو تطبيق آخر"))
        }
    }
}

private class DesignedPdfWriter(private val document: PdfDocument) {
    private val pageWidth = 595
    private val pageHeight = 842
    private val margin = 30f
    private val contentWidth = pageWidth - margin * 2
    private var pageNumber = 0
    private var page: PdfDocument.Page? = null
    private var canvas: Canvas? = null
    private var cursor = 0f

    init { startPage() }

    fun drawParagraph(text: String, size: Float, color: Int, bold: Boolean, gapAfter: Float = 6f) {
        val layout = makeLayout(text, size, color, bold, contentWidth.toInt())
        ensureSpace(layout.height + gapAfter)
        val c = canvas ?: return
        c.save()
        c.translate(margin, cursor)
        layout.draw(c)
        c.restore()
        cursor += layout.height + gapAfter
    }

    fun drawSection(title: String) {
        ensureSpace(48f)
        val c = canvas ?: return
        val top = cursor
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GreenPdf; style = Paint.Style.FILL }
        c.drawRoundRect(RectF(margin, top, pageWidth - margin, top + 34f), 10f, 10f, paint)
        val layout = makeLayout(title, 14f, WhitePdf, true, contentWidth.toInt() - 20)
        c.save()
        c.translate(margin + 10f, top + 7f)
        layout.draw(c)
        c.restore()
        cursor += 44f
    }

    fun drawMetrics(metrics: List<Pair<String, String>>) {
        val gap = 8f
        val cardWidth = (contentWidth - gap * (metrics.size - 1)) / metrics.size
        val cardHeight = 70f
        ensureSpace(cardHeight + 12f)
        val c = canvas ?: return
        metrics.forEachIndexed { index, metric ->
            val left = margin + index * (cardWidth + gap)
            val rect = RectF(left, cursor, left + cardWidth, cursor + cardHeight)
            val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PaleGreenPdf; style = Paint.Style.FILL }
            c.drawRoundRect(rect, 10f, 10f, background)
            val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SoftGreenPdf; style = Paint.Style.STROKE; strokeWidth = 1f }
            c.drawRoundRect(rect, 10f, 10f, border)
            val title = makeLayout(metric.first, 10.5f, GrayPdf, false, (cardWidth - 12f).toInt())
            c.save(); c.translate(left + 6f, cursor + 10f); title.draw(c); c.restore()
            val value = makeLayout(metric.second, 12f, DarkGreenPdf, true, (cardWidth - 12f).toInt())
            c.save(); c.translate(left + 6f, cursor + 35f); value.draw(c); c.restore()
        }
        cursor += cardHeight + 12f
    }

    fun drawCard(title: String, body: String, accent: Int) {
        val titleLayout = makeLayout(title, 13f, DarkGreenPdf, true, contentWidth.toInt() - 24)
        val bodyLayout = makeLayout(body, 11.5f, TextPdf, false, contentWidth.toInt() - 24)
        val cardHeight = titleLayout.height + bodyLayout.height + 26f
        ensureSpace(cardHeight + 8f)
        val c = canvas ?: return
        val top = cursor
        val rect = RectF(margin, top, pageWidth - margin, top + cardHeight)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CardPdf; style = Paint.Style.FILL }
        c.drawRoundRect(rect, 10f, 10f, fill)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SoftGreenPdf; style = Paint.Style.STROKE; strokeWidth = 0.8f }
        c.drawRoundRect(rect, 10f, 10f, stroke)
        val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; strokeWidth = 3f; style = Paint.Style.STROKE }
        c.drawLine(pageWidth - margin - 1.5f, top + 8f, pageWidth - margin - 1.5f, top + cardHeight - 8f, marker)
        c.save(); c.translate(margin + 12f, top + 9f); titleLayout.draw(c); c.restore()
        c.save(); c.translate(margin + 12f, top + 12f + titleLayout.height); bodyLayout.draw(c); c.restore()
        cursor += cardHeight + 8f
    }

    fun finish() {
        finishCurrentPage()
    }

    private fun ensureSpace(required: Float) {
        if (cursor + required > pageHeight - 44f) startPage()
    }

    private fun startPage() {
        finishCurrentPage()
        pageNumber += 1
        val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        val newPage = document.startPage(info)
        page = newPage
        canvas = newPage.canvas
        newPage.canvas.drawColor(WhitePdf)
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GreenPdf; style = Paint.Style.FILL }
        newPage.canvas.drawRoundRect(RectF(0f, 0f, pageWidth.toFloat(), 68f), 0f, 0f, headerPaint)
        val title = makeLayout("دفتر حسابات", 20f, WhitePdf, true, contentWidth.toInt())
        newPage.canvas.save(); newPage.canvas.translate(margin, 11f); title.draw(newPage.canvas); newPage.canvas.restore()
        val subtitle = makeLayout("كشف مالي مفصل  •  سعر الصرف وفق الإعدادات والسجلات", 10.5f, WhitePdf, false, contentWidth.toInt())
        newPage.canvas.save(); newPage.canvas.translate(margin, 43f); subtitle.draw(newPage.canvas); newPage.canvas.restore()
        cursor = 82f
    }

    private fun finishCurrentPage() {
        val current = page ?: return
        val c = current.canvas
        val rule = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SoftGreenPdf; strokeWidth = 1f }
        c.drawLine(margin, pageHeight - 35f, pageWidth - margin, pageHeight - 35f, rule)
        val footer = makeLayout("دفتر حسابات   •   صفحة $pageNumber", 9f, GrayPdf, false, contentWidth.toInt())
        c.save(); c.translate(margin, pageHeight - 29f); footer.draw(c); c.restore()
        document.finishPage(current)
        page = null
        canvas = null
    }

    private fun makeLayout(text: String, size: Float, color: Int, bold: Boolean, width: Int): StaticLayout {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setLineSpacing(2f, 1f)
            .build()
    }
}

data class ExpenseRowForReport(
    val name: String,
    val category: String,
    val amountSar: Double,
    val amountYer: Double,
    val trader: String = "",
    val createdBy: String = "مازن",
    val dateText: String = "",
    val dateMillis: Long = System.currentTimeMillis(),
    val paidAmountSar: Double = amountSar,
    val paidAmountYer: Double = amountYer,
    val currency: String = "SAR"
)

private fun isWageCategory(category: String): Boolean = category == "أجور" || category == "رواتب" || category.contains("أجر")

private fun formatMoney(value: Double): String = String.format(Locale.US, "%,.2f", value).trimEnd('0').trimEnd('.')

private val GreenPdf = 0xFF2E7D32.toInt()
private val DarkGreenPdf = 0xFF1B5E20.toInt()
private val PaleGreenPdf = 0xFFE8F5E9.toInt()
private val SoftGreenPdf = 0xFFC8E3C9.toInt()
private val CardPdf = 0xFFF8FBF8.toInt()
private val TextPdf = 0xFF263229.toInt()
private val GrayPdf = 0xFF68736A.toInt()
private val WhitePdf = 0xFFFFFFFF.toInt()
