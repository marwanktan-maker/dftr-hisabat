package com.hasabi.app2024

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID

object LedgerPersistence {
    fun transferDocumentId(number: String): String {
        val normalized = number.trim().uppercase(Locale.ROOT)
        if (normalized.isBlank()) return UUID.randomUUID().toString()
        val digest = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    fun loadTransfers(raw: String?): MutableList<Hawala> {
        if (raw.isNullOrBlank()) return mutableListOf()
        return runCatching {
            val a = JSONArray(raw)
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                val received = o.optBoolean("received")
                val sentYer = o.optDouble("amountYER", o.optDouble("amountSAR") * Constants.EXCHANGE_RATE)
                Hawala(
                    id = o.optString("id"), number = o.optString("number"),
                    amountSAR = o.optDouble("amountSAR"), amountYER = sentYer,
                    from = o.optString("from"), recipient = o.optString("recipient", "مازن"),
                    date = o.optLong("date"), createdBy = o.optString("createdBy"),
                    received = received,
                    receivedCurrency = o.optString("receivedCurrency", "YER"),
                    receivedAmount = o.optDouble("receivedAmount", sentYer),
                    receivedAt = o.optLong("receivedAt", if (received) o.optLong("date") else 0L),
                    receiptImage = o.optString("receiptImage"),
                    exchangeRateAtEntry = o.optDouble("exchangeRateAtEntry", Constants.EXCHANGE_RATE),
                    receivedExchangeRate = o.optDouble("receivedExchangeRate", Constants.EXCHANGE_RATE)
                )
            }
        }.getOrElse { mutableListOf() }
    }

    fun saveTransfers(prefs: SharedPreferences, transfers: List<Hawala>) {
        val a = JSONArray()
        transfers.forEach { t -> a.put(JSONObject()
            .put("id", t.id).put("number", t.number).put("amountSAR", t.amountSAR)
            .put("amountYER", t.amountYER).put("from", t.from).put("recipient", t.recipient)
            .put("date", t.date).put("createdBy", t.createdBy).put("received", t.received)
            .put("receivedCurrency", t.receivedCurrency).put("receivedAmount", t.receivedAmount)
            .put("receivedAt", t.receivedAt)
            .put("receiptImage", t.receiptImage)
            .put("exchangeRateAtEntry", t.exchangeRateAtEntry)
            .put("receivedExchangeRate", t.receivedExchangeRate)) }
        prefs.edit().putString("transfers", a.toString()).apply()
    }

    fun loadWorkers(raw: String?): MutableList<WorkerDaily> {
        if (raw.isNullOrBlank()) return mutableListOf()
        return runCatching {
            val a = JSONArray(raw)
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                WorkerDaily(o.optString("name"), o.optString("job"), o.optInt("days", 1),
                    o.optDouble("dailyWageYER"), o.optDouble("dailyWageSAR"), o.optBoolean("paid"),
                    o.optLong("date"), o.optString("createdBy", "مازن"),
                    o.optDouble("paidAmountSAR", if (o.optBoolean("paid")) o.optDouble("dailyWageSAR") * o.optInt("days", 1) else 0.0),
                    o.optDouble("paidAmountYER", if (o.optBoolean("paid")) o.optDouble("dailyWageYER") * o.optInt("days", 1) else 0.0),
                    o.optDouble("exchangeRateAtEntry", Constants.EXCHANGE_RATE))
            }
        }.getOrElse { mutableListOf() }
    }

    fun saveWorkers(prefs: SharedPreferences, workers: List<WorkerDaily>) {
        val a = JSONArray()
        workers.forEach { w -> a.put(JSONObject().put("name", w.name).put("job", w.job)
            .put("days", w.days).put("dailyWageYER", w.dailyWageYER).put("dailyWageSAR", w.dailyWageSAR)
            .put("paid", w.paid).put("date", w.date).put("createdBy", w.createdBy)
            .put("paidAmountSAR", w.paidAmountSAR).put("paidAmountYER", w.paidAmountYER)
            .put("exchangeRateAtEntry", w.exchangeRateAtEntry)) }
        prefs.edit().putString("workers", a.toString()).apply()
    }
}
